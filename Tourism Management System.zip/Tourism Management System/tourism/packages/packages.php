<?php
include '../dashboard/dbconn/dbconn.php';

// SQL Query to get the top three drivers, guiders, hotels, and packages

// Top three packages
$query_packages = "SELECT * FROM packages ORDER BY packageid DESC LIMIT 3";
$result_packages = $conn->query($query_packages);

// Display the results
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Popular Hotels - DHULmar</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
    }

    header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }


    /* Cards container */
    .cards-container {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
      padding: 40px;
    }

    .card {
      background-color: white;
      border-radius: 15px;
      padding: 20px;
      width: 280px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: transform 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 240px;
      border-radius: 10px;
      object-fit: cover;
    }

    .card h3 {
      margin: 15px 0 5px;
      font-size: 20px;
    }

    .card p {
      margin: 5px 0;
    }

    .star {
      color: gold;
    }

    .view-btn {
      display: inline-block;
      margin-top: 12px;
      padding: 8px 16px;
      background-color: #00bcd4;
      color: white;
      border-radius: 20px;
      text-decoration: none;
      font-weight: bold;
      transition: background 0.3s;
    }

    .view-btn:hover {
      background-color: #0097a7;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header>
    <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
    <nav>
        <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>

            
        </ul>
    </nav>
    <a href="../login/login.php"><button class="login">Login</button></a>
</header>

  <!-- Title -->
  <h1 class="title">Packages</h1>
  <!-- Cards -->
  <div class="cards-container">
    <?php while ($package = $result_packages->fetch_assoc()): ?>
    <?php $query_sites = "SELECT imagepath FROM toursites WHERE siteid = ".$package['siteid']; ?>
    <?php $sites = $conn->query($query_sites); ?>
    <?php $site = $sites->fetch_assoc(); ?>
    <!-- Card 1 -->
    <div class="card">
      <img src="../dashboard/toursites/media/<?= $site['imagepath'] ?>" alt="<?= htmlspecialchars($package['packagename']) ?>" />
      <h3><?= htmlspecialchars($package['packagename']) ?></h3>
      <p>📅 <?= htmlspecialchars($package['durationdays']) ?> Day Trip</p>
      <p><span class="star">⭐</span> <?= htmlspecialchars($package['price']) ?></p>
    </div>
    <?php endwhile; ?>
  </div>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
