<?php
session_start();
require_once '../dashboard/dbconn/dbconn.php';

$stage = 1;
$securityquestion = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Step 1: Verify Email & Phone
    if (isset($_POST['step']) && $_POST['step'] == '1') {
        $email = trim($_POST['email']);
        $username = trim($_POST['username']);

        if (!empty($email) && !empty($username)) {
            $stmt = $conn->prepare("SELECT secques FROM users WHERE email = ? AND username = ?");
            $stmt->bind_param("ss", $email, $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($securityquestion);
                $stmt->fetch();
                $_SESSION['resetemail'] = $email;
                $_SESSION['resetusername'] = $username;
                $_SESSION['securityquestion'] = $securityquestion;
                $stage = 2;
            } else {
                echo "<script>alert('Invalid email or username.')</script>"; // Use JavaScript to display the alert
            }
            $stmt->close();
        } else {
            echo "<script>alert('All fields are required.')</script>"; // Use JavaScript to display the alert 
        }
    }

    // Step 2: Check security answer + update password
    if (isset($_POST['step']) && $_POST['step'] == '2') {
        $email = $_SESSION['resetemail'] ?? '';
        $username = $_SESSION['resetusername'] ?? '';
        $securityanswer = trim($_POST['secans']);
        $newpassword = trim($_POST['password']);
        $confirmpassword = trim($_POST['confirm']);

        if (empty($securityanswer) || empty($newpassword) || empty($confirmpassword)) {
            echo "<script>alert('All fields are required.')</script>";
            $stage = 2;
        } elseif ($newpassword !== $confirmpassword) {
            echo "<script>alert('Passwords do not match.')</script>"; // Use JavaScript to display the alert
            $stage = 2;
        } else {
            $stmt = $conn->prepare("SELECT userid FROM users WHERE email = ? AND username = ? AND secans = ?");
            $stmt->bind_param("sss", $email, $username, $securityanswer);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $hashed = password_hash($newpassword, PASSWORD_BCRYPT);
                $update = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $update->bind_param("ss", $hashed, $email);
                if ($update->execute()) {
                    echo "<script>alert('Password reset successful. You can now login.')</script>"; // Use JavaScript to display the alert
                    session_destroy();
                    $stage = 1;
                } else {
                    echo "<script>alert('Failed to update password.')</script>"; // Use JavaScript to display the alert
                    $stage = 2;
                }
                $update->close();
            } else {
                echo "<script>alert('Incorrect security answer.')</script>"; // Use JavaScript to display the alert
                $stage = 2;
            }
            $stmt->close();
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../login/login.css">
</head>
<body>

    <div class="container">
        <!-- Login Form Section -->
        <div class="form-container">
            <h2>Verify</h2>
            <p>If you have already a member. Easily Verify </p>
            <?php if ($stage === 1): ?>
            <form action="forgot.php" method="POST">
                <input type="hidden" name="step" value="1">
                <input type="text" name="username" placeholder="Enter your username">
                <input type="email" name="email" placeholder="Enter your email">

                <button type="submit" name="verify" class="login-btn">Verify</button>
            </form>
            <?php elseif ($stage === 2): ?>
            <form action="forgot.php" method="POST">
                <input type="hidden" name="step" value="2">
                <input type="text" name="secques" placeholder="security question" value="<?= htmlspecialchars($_SESSION['securityquestion']) ?>" readonly>
                <input type="text" name="secans" placeholder="Enter your security answer">
                <input type="password" name="password" placeholder="Enter your password">
                <input type="password" name="confirm" placeholder="Enter your confirm password">
                <button type="submit" name="reset" class="login-btn">Reset</button>
            </form>
            <?php endif; ?>
            <p class="forgot-password"><a href="../login/login.php" class="forgot-password">Login</a></p>
        </div>

        <!-- Side Image Section -->
        <div class="image-container">
            <img src="../forgot/dhulmar.png" alt="Location Icon">
        </div>
    </div>

</body>
</html>
