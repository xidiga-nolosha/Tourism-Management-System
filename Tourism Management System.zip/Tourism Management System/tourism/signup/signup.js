/*document.getElementById("signupForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const username = document.getElementById("username").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;
    const profileImage = document.getElementById("profileImage").files[0];
  
    const reader = new FileReader();
  
    reader.onload = function () {
      // Save data to localStorage
      localStorage.setItem("userData", JSON.stringify({
        username,
        phone,
        email,
        image: reader.result
      }));
  
      // Redirect to profile page
      window.location.href = "profile.html";
    };
  
    if (profileImage) {
      reader.readAsDataURL(profileImage);
    }
  });
  */