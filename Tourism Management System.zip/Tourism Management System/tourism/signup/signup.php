<?php
include '../dashboard/dbconn/dbconn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collecting data from the form
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $secques = $_POST['secques'];
    $secans = $_POST['secans'];
    $role = 'customer';

    // Check for existing username
    $checkStmt = $conn->prepare("SELECT userid FROM users WHERE username = ?");
    $checkStmt->bind_param("s", $username);
    $checkStmt->execute();
    $checkStmt->store_result();
    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Username already exists. Please choose a different username.');</script>";
        exit();
    }
    $checkStmt->close();

    if (isset($_FILES['imagepath']) && $_FILES['imagepath']['error'] === UPLOAD_ERR_OK) {

      // Get the temporary name and original name of the uploaded file
      $tmpName = $_FILES['imagepath']['tmp_name'];
      $originalName = $_FILES['imagepath']['name'];

      // Get the file extension
      $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

      // Sanitize the model name to be safe for filenames
      $safeUser = preg_replace("/[^a-zA-Z0-9_-]/", "", $_POST['username']);

      // Create a unique file name
      $newFileName = $safeUser . "_" . time() . "." . $extension;

      // Define the target upload path
      $uploadPath = "../dashboard/users/media/" . $newFileName;

      // Move the uploaded file to the destination folder
      if (move_uploaded_file($tmpName, $uploadPath)) {
          $image = $newFileName; // You can store this in your database
      } else {
          echo "<script>alert('Failed to upload image.');</script>";
          exit();
      }
    } 

    // Inserting data into the users table
    $stmt = $conn->prepare("INSERT INTO users (fullname, imagepath, email, phone, username, password, secques, secans, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssisssss", $fullname, $image, $email, $phone, $username, $pass, $secques, $secans, $role);

    if ($stmt->execute()) {
        header("Location: ../login/login.php");
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    $stmt->close();
    $conn->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link rel="stylesheet" href="./signup.css">
</head>
<body>

  <div class="container">
    <!-- Form Section -->
    <div class="form-container">
      <h2>Create Account</h2>
      <p>Please provide your personal credentials.</p>

      <form id="signupForm" enctype="multipart/form-data" action="signup.php" method="POST">
        <input type="text" name="fullname" id="fullname" placeholder="fullname" required>
        <input type="file" name="imagepath" id="profileImage" accept="image/*">
        <input type="text" name="secques" id="secquestion" placeholder="security question" required>
        <input type="text" name="secans" id="secanswer" placeholder="security answer" required>

        <div class="input-group">
          <input type="text" name="username" id="username" placeholder="Username" required>
          <input type="tel" name="phone" id="phone" placeholder="Phone" required>
        </div>
        <input type="email" id="email" name="email" placeholder="Email" required>
        <input type="password" name="password" id="password" placeholder="Password" required>
        <input type="password" name="confirm" id="confirmPassword" placeholder="Confirm Password" required>

       <button type="submit" class="register-btn">Register</button>
      </form>

      <p class="login-text">If you already have an account go! <a href="../login/login.php">Login!</a></p>
    </div>

    <!-- Side Image Section -->
    <div class="image-container">
      <img src="./dhulmar.png" alt="Location Icon">
    </div>
  </div>

  <!--<script src="./signup.js"></script>-->
</body>
</html>
