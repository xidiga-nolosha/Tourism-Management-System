<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f6ffff;
    }

    header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

    .contact-header {
      position: relative;
      background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e');
      background-size: cover;
      background-position: center;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 2.5rem;
      font-weight: bold;
      text-shadow: 2px 2px 6px #000;
    }

    .contact-header::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
      z-index: 0;
    }

    .contact-header span {
      position: relative;
      z-index: 1;
    }

    h2 {
      text-align: center;
      color: #00cde2;
      margin-top: 40px;
    }

    .about-section {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: 40px 60px;
      gap: 40px;
    }

    .about-text {
      flex: 1;
      font-size: 1.1rem;
      line-height: 1.7;
      color: #333;
    }

    .about-image {
      flex: 1;
      display: flex;
      justify-content: center;
    }

    .about-image img {
      width: 100%;
      max-width: 450px;
      height: auto;
    }

    @media (max-width: 768px) {
      .about-section {
        flex-direction: column;
        text-align: center;
        padding: 20px;
      }

      .about-image img {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>

    <header>
        <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>

                
            </ul>
        </nav>
        <a href="../login/login.php"><button class="login">Login</button></a>
    </header>

<div class="contact-header">
  <span>About Us</span>
</div>
    <h2>Who We Are</h2>

<section class="about-section">
  <div class="about-text">
    <p>
        DHulMar is more than just a travel website – it’s your trusted partner in discovering the Somaliland. Whether you're planning a relaxing beach getaway, a thrilling mountain adventure, or a cultural exploration through historic cities, DHulMar is here to make every step of your journey easy, exciting, and memorable.    </p>
    <p>
        We offer a wide range of travel services tailored to meet your needs:</p>

       <p> 🌍 Travel Packages – We carefully design travel packages for individuals, couples, families, and groups. From all-inclusive resorts to budget-friendly road trips, there’s something for everyone.
        
        🏨 Hotel Bookings – Find the best accommodation options at unbeatable prices. Our hotel section includes everything from luxurious five-star hotels to cozy guesthouses, all handpicked for comfort and quality.  
    <p>🧭 Professional Tour Guiders – Enjoy a guided experience led by local experts who know the hidden gems, traditions, and stories of each destination. Our guiders speak multiple languages and are trained in hospitality and safety.</p>
    </div>
  
  
        <div class="about-image">
    <img src="./about.png" alt="about us image">
  </div>
</section>

</body>
</html>
