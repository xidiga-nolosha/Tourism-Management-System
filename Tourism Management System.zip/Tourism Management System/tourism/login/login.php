<?php
include '../dashboard/dbconn/dbconn.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collecting login data
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Query to get user data
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifying password
        if (password_verify($password, $user['password'])) {
            $_SESSION['userid'] = $user['userid'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['image'] = $user['imagepath'];
            header("Location: ../dashboard/dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('User not found!');</script>";
    }

    $stmt->close();
    $conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./login.css">
</head>
<body>

    <div class="container">
        <!-- Login Form Section -->
        <div class="form-container">
            <h2>Login</h2>
            <p>If you have already a member. Easily Log In</p>
            <form action="login.php" method="POST">
                <input type="text" name="username" placeholder="Enter your username" required>
                <input type="password" name="password" placeholder="Enter your password" required>
                <button type="submit" class="login-btn">Login</button>
            </form>
            <p class="forgot-password"><a href="../forgot/forgot.php" class="forgot-password">Forget Password!</a></p>

            <p class="signup-text">If you don’t have an account <a href="../signup/signup.php">Create</a></p>
        </div>

        <!-- Side Image Section -->
        <div class="image-container">
            <img src="./dhulmar.png" alt="Location Icon">
        </div>
    </div>

</body>
</html>


