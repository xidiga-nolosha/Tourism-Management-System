<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Somaliland Weekly News</title>
  <link rel="stylesheet" href="./toursites.css" />
</head>
<body>

    <header>
        <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>
                
                
            </ul>
        </nav>
        <a href="../login/login.php"><button class="login">Login</button></a>
    </header>
<br>
<br>
  <div class="container">
    <h1 class="site-title">Tour Site</h1>
    <h2 class="main-heading">Somaliland’s Top Tour: 7 Days of Magic!</h2>
    <p class="description">
        Journey through Hargeisa’s history, Berbera coasts, and more—all in one thrilling week! <br>
        Hargeisa’s history, Berbera coasts, and more—all in <br>
        Journey through Hargeisa’s history    </p>

    <div class="card-grid">
      <!-- MAIN TRENDING STORY -->
      <div class="card card-image dark wide">
        <img src="https://images.unsplash.com/photo-1600208537475-6cdbf234ca5d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGJlYWNoZXN8ZW58MHx8MHx8fDA%3D" alt="Berbera Coast">
        <div class="text-overlay">
          <h3>🔥 Berbera Coast is on fire this week!</h3>
          <p>
            Tourists are flocking to Berbera's stunning coastline, as this week marks one of the busiest <br>and most exciting beach moments in recent history.<br> Local events, food festivals, and historic walks are just the beginning!
          </p>
        </div>
      </div>

      <!-- STORY 2 -->
      <div class="card card-text blue">
        <h3>Photography Festival kicks off in Hargeisa</h3>
        <p>
          This week, local and international photographers showcase Somaliland's scenic beauty and culture at Hargeisa's annual photo fest.
        </p>
        
      </div>

      <!-- STORY 3 -->
      <div class="card card-text blue">
        <h3>Berbera-Hargeisa Highway Expansion Begins</h3>
        <p>
          The long-awaited road project connecting Berbera and Hargeisa starts this week. Officials say it's a major boost for trade and tourism.
        </p>
        
      </div>

     
    </div>
  </div>

</body>
</html>
