<?php
include '../dashboard/dbconn/dbconn.php';

// SQL Query to get the top three drivers, guiders, hotels, and packages


// Top three guiders
$query_guiders = "SELECT * FROM guiders ORDER BY expertyear DESC LIMIT 3";
$result_guiders = $conn->query($query_guiders);


// Display the results
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tour Guides</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      text-align: center;
    }

    /* Header/Navbar */
    header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }
    h2 {
      text-align: center;
      margin: 40px 0 30px;
      color: #00cde2;
      font-size: 26px;
    }

    .guides-container {
      display: flex;
      justify-content: space-evenly;
      gap: 30px;
      flex-wrap: wrap;
      max-width: 1200px;
      margin: 0 auto 40px;
    }

    .guide-card {
      background-color: #025763;
      color: white;
      border-radius: 25px;
      width: 280px;
      padding: 60px 20px 30px;
      position: relative;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .guide-card img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      position: absolute;
      top: -60px;
      left: 50%;
      transform: translateX(-50%);
      border: 5px solid white;
    }

    .stars {
      color: gold;
      font-size: 20px;
      margin-bottom: 10px;
    }

    .guide-name {
      font-weight: bold;
      font-size: 20px;
      margin: 10px 0 5px;
    }

    .guide-info {
      font-size: 14px;
      margin-bottom: 20px;
    }

    .hire-btn {
      background-color: #00d2f3;
      border: none;
      color: black;
      padding: 12px 25px;
      font-weight: bold;
      border-radius: 30px;
      cursor: pointer;
      font-size: 16px;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      transition: background-color 0.3s ease;
    }

    .hire-btn:hover {
      background-color: #00b4d0;
    }

    .arrow {
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header>
    <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../hotels/hotels.php">Hotels</a></li>
            <li><a href="../packages/packages.php">Packages</a></li>
            <li><a href="../guiders/guiders.php">Guiders</a></li>
            <li><a href="../about/about.php">Who we are</a></li>
            <li><a href="../drivers/drivers.php">Drivers</a></li>
            <li><a href="../contact/contact.php">Contact</a></li>

            
        </ul>
    </nav>
    <a href="../login/login.php"><button class="login">Login</button></a>
</header>
<br>
<br>
  <!-- Title -->
  <h2>Meet Our Tour Guides</h2>
<br>
<br>
  <!-- Guide Cards -->
  <div class="guides-container">
    <?php while ($guider = $result_guiders->fetch_assoc()): ?>
    <div class="guide-card">
      <img src="../dashboard/guiders/media/<?= htmlspecialchars($guider['imagepath']) ?>" alt="<?= htmlspecialchars($guider['fullname']) ?>">
      <br>
      <div class="stars">
        ★ ★ ★ ★ ★
      </div>
      <div class="guide-name">
        <?= htmlspecialchars($guider['fullname']) ?>
      </div>
      <div class="guide-info">Excellent <?= htmlspecialchars($guider['special']) ?> with and got 
        <br /><?= $guider['expertyear'] ?>+ years experience.
      </div>
    </div>
    <?php endwhile; ?>
  </div>

  <br>
  <br>
  <br>

   <?php
// Close the connection
$conn->close();
?>

</body>
</html>
