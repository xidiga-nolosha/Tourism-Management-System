<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Dhulmar</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            height: 10%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

        /* HERO SECTION */
        .hero {
            background: linear-gradient(to right, rgba(0, 0, 0, 0.7), rgba(1, 1, 1, 0) 75%), url('./1.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            padding-left: 50px;
            text-align: left;
        }

        .content {
            max-width: 600px;
        }

        .content h2 {
            font-size: 24px;
        }

        .content h2 span {
            color: #00bcd4;
        }

        .content h1 {
            font-size: 36px;
            font-weight: bold;
        }

        .content p {
            margin: 20px 0;
            font-size: 16px;
        }

        .book-now {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 29px;
            font-size: 18px;
            cursor: pointer;
        }

        /* HIGHLIGHTS SECTION */
        .highlights {
            text-align: center;
            padding: 80px 20px;
            background-color: #f5f5f5;
        }

        .highlights h2 {
            font-size: 28px;
            font-weight: bold;
            color: #00bcd4;
            margin-bottom: 30px;
        }

        .cards {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .card {
            background-color: #26c6da;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            color: black;
            width: 300px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1);
        }

        .card img {
            width: 50px;
            height: 50px;
            margin-bottom: 10px;
        }

        .card h3 {
            font-size: 22px;
            font-weight: bold;
        }

        .card p {
            font-size: 14px;
            margin-top: 10px;
        }


        

        .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 80%;
            height: 90%;
        }

        .images {
            position: relative;
            width: 70%;
            display: flex;
            align-items: center;
            margin-left: 90px;
            margin-bottom: 180px;


        }

        .images img {
            width: 225px;
            height: 200px;
            border-radius: 30px;
            object-fit: cover;
            position: absolute;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2);
        }

        .images img:nth-child(1) {
            top: 0;
            left: 0;
            transform: rotate(-10deg);
        }

        .images img:nth-child(2) {
            top: 50px;
            left: 100px;
            transform: rotate(5deg);
        }

        .images img:nth-child(3) {
            top: 120px;
            left: 50px;
            transform: rotate(-5deg);
        }

        .text-content {
            width: 90%;
            padding-left: 50px;
            margin-left: 25px;
            margin-top: 55px;
        }

        .text-content h2 {
            font-size: 28px;
            font-weight: bold;
            color: #0097a7;
        }

        .text-content h3 {
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            margin: 10px 0;
            position: relative;
        }

        .text-content h3::after {
            content: "";
            width: 50px;
            height: 3px;
            background-color: #0097a7;
            position: absolute;
            bottom: -5px;
            left: 0;
        }

        .text-content h1 {
            font-size: 30px;
            font-weight: bold;
            color: #0097a7;
            margin: 20px 0;
            text-shadow: none;
        }

        .text-content p {
            font-size: 16px;
            color: #333;
            line-height: 1.5;
            margin-bottom: 20px;
        }

        .btn {
            background-color: #0097a7;
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 12px 25px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn img {
            width: 20px;
            height: 20px;
        }

        .who-section {
          background: linear-gradient(to bottom right, #c5eaee, #ffffff);
          padding: 45px 0 100px; /* Bottom padding kordhay */
          box-shadow: 0 5px 20px rgba(0,0,0,0.1);
          width: 100%;
        }



        .packages {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .package {
            background: #fff;
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: left;
            width: 250px;
        }

        .package img {
            width: 100%;
            height: 150px;
            border-radius: 10px;
            object-fit: cover;
        }

        .package h3 {
            margin: 10px 0;
            font-size: 18px;
        }

        .package p {
            margin: 5px 0;
            font-size: 14px;
        }

        .price {
            font-size: 18px;
            font-weight: bold;
            color: #000;
        }

        .rating {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .rating img {
            width: 14px;
            height: 14px;
            margin-left: 5px;
        }
        .package1 h2 {
            font-size: 28px;
            font-weight: bold;
            color: #00bcd4;
            margin-bottom: 30px;
            text-align: center;
        }
    
        .tour {
          font-family: 'Georgia', serif;
          margin-top: 30px;
          padding: 40px;
          background: #fff;
          }

          .tour-h3 {
            text-align: center;
            color: #00bcd4; /* turquoise */
            font-size: 1.5em;
          }

          .tour-spotlight {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 40px;
            position: relative;
          }

          .tour-spotlight img {
            width: 600px;
            height: auto;
            border-radius: 24px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
          }

          .tour-card {
            position: absolute;
            right: 10%;
            background-color: #004d4d;
            color: white;
            padding: 24px;
            width: 300px;
            border-radius: 24px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
          }

          .tour-card h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
          }

          .tour-card p {
            font-size: 0.9em;
            margin-bottom: 20px;
            line-height: 1.4;
          }

          .tour-card button {
            padding: 10px 20px;
            background-color: #cfe8e8;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
          }

          .tour-card button:hover {
            background-color: #b2d8d8;
          }

          .destination-section {
            font-family: Arial, sans-serif;
            padding: 50px;
            background-color: white;
            text-align: center;
          }

          .destination-section h2 {
            font-size: 32px;
            color: #00a7b3;
            font-weight: bold;
          }

          .destination-section p {
            font-size: 16px;
            color: #333;
            margin-top: 10px;
            margin-bottom: 40px;
          }

          .destinations {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
          }

          .destinations img {
            width: 200px;
            height: 200px;
            object-fit: cover;
            border-radius: 25px;
            transform: rotate(-8deg);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
            
          }

          .destinations img:nth-child(2) {
            transform: rotate(0deg);
          }

          .destinations img:nth-child(3) {
            transform: rotate(8deg);
          }

          .destinations img:hover {
            transform: scale(1.05);
          }

          .discover {
            background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e'); /* Background sawirka la mid ah */
            background-size: cover;
            background-position: center;
            height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 20px;
            color: white;
            
            
          }

          h1 {
            font-size: 36px;
            font-weight: 800;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.6);
            margin-bottom: 40px;
          }

          .search-container {
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
            border-radius: 50px;
            padding: 5px;
            width: 90%;
            max-width: 500px;
          }

          .search-container input {
            border: none;
            outline: none;
            padding: 15px 20px;
            flex: 1;
            font-size: 16px;
            border-radius: 50px;
          }

          .search-container button {
            background-color: #00bcd4;
            color: white;
            border: none;
            padding: 15px 25px;
            border-radius: 50px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s;
          }

          .search-container button:hover {
            background-color: #0097a7;
          }

          @media (max-width: 600px) {
            h1 {
              font-size: 28px;
            }
            .search-container {
              flex-direction: column;
              padding: 10px;
              gap: 10px;
            }
            .search-container button {
              width: 100%;
              margin-left: 0;
            }
          }

          .f {
            margin: 0;
            font-family: Arial, sans-serif;
          }

          .footer {
            background-color: #d6f2f3;
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
            padding: 40px 20px;
            flex-wrap: wrap;
          }

          .footer-section {
            flex: 1;
            margin: 10px;
            min-width: 200px;
          }

          .footer-section h3 {
            font-weight: bold;
            margin-bottom: 20px;
          }

          .logo {
            font-size: 28px;
            font-weight: bold;
          }

          .logo span {
            color: orange;
          }

          .footer-section ul {
            list-style-type: disc;
            padding-left: 110px;
          }
          .footer-section h3{
              padding-left: 90px;
          }

          .footer-section ul li {
            margin-bottom: 10px;
            color: #444;
          }

          .footer-section p {
            color: #444;
            margin-bottom: 10px;
          }

          .social-icons  {
            margin-right: 10px;
            padding-left: 30px;
            font-size: 18px;
          }

          .bottom-bar {
            background-color: #006d80;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            flex-wrap: wrap;
          }

          .bottom-bar div {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
          }

          .bottom-bar img {
            width: 20px;
          }



          .footer-subscribe {
        color: white;
        text-align: center;
        padding: 40px 20px;
        border-radius: 92px;
      }

      .footer-subscribe h3 {
        font-size: 24px;
        margin-bottom: 10px;
      }

      .footer-subscribe p {
        font-size: 16px;
        margin-bottom: 20px;
        color: #ccc;
      }

      .footer-subscribe form {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
      }

      .footer-subscribe textarea {
        width: 250px;
        height: 40px;
        padding: 10px;
        border-radius: 26px;
        border: none;
        resize: none;
        font-size: 14px;
      }

      .footer-subscribe button {
        padding: 10px 20px;
        background-color: #00bcd4;
        color: white;
        border: none;
        border-radius: 26px;
        font-size: 14px;
        cursor: pointer;
        transition: background-color 0.3s;
      }

      .footer-subscribe button:hover {
        background-color: #0097a7;
      }

    </style>
</head>
<body>
    <header>
        <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
        <nav>
            <ul>
                <li><a href="./index.php">Home</a></li>
                <li><a href="./hotels/hotels.php">Hotels</a></li>
                <li><a href="./packages/packages.php">Packages</a></li>
                <li><a href="./guiders/guiders.php">Guiders</a></li>
                <li><a href="./about/about.php">Who we are</a></li>
                <li><a href="./drivers/drivers.php">Drivers</a></li>
                <li><a href="./contact/contact.php">Contact</a></li>

                
            </ul>
        </nav>
        <a href="./login/login.php"><button class="login">Login</button></a>
    </header>

    <section class="hero">
        <div class="content">
            <h2>Welcome to <span>Dhulmar</span></h2>
            <h1>Let's Discover The World Together</h1>
            <p>Tourism is a social, cultural, and economic phenomenon which entails the movement of people to countries or places outside their usual environment for personal, business, or professional purposes.</p>
            <a href="./login/login.php"><button class="book-now">Book Now</button></a>
        </div>
    </section>

    <section class="highlights">
        <h2>Explore Our Highlights</h2>
        <div class="cards">
            <div class="card" style="background-color: #38EEFF;">
                <img src="https://img.icons8.com/?size=100&id=IgD1T1Mih0Ja&format=png&color=000000" alt="Packages">
                <h3>Packages</h3>
                <p>Discover tailored travel packages for every budget and taste. Adventure, relaxation, or exploration.</p>
            </div>
            <div class="card" style="background-color: #03B4C4;">
                <img src="https://img.icons8.com/?size=100&id=74CHXrw7kLSv&format=png&color=000000" alt="Hotels">
                <h3>Hotels</h3>
                <p>Book the best hotels with top-rated comfort and luxury.</p>
            </div>
            <div class="card" style="background-color: #38EEFF;">
                <img src="https://img.icons8.com/?size=100&id=aTU2t2KCrc77&format=png&color=000000" alt="Destinations">
                <h3>Destinations</h3>
                <p>Explore the world’s most stunning destinations. From tropical beaches to historic landmarks.</p>
            </div>
        </div>
    </section>


<section class="who-section">
    <div class="container">
        <div class="images">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSww_05KETpYVXI9ZWTpnXddMvf7HAHu6v_kA&s" alt="laasgeel">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf70TLjziclV5h_Dh6KzIuAU92jjg5G_K__sXLPFTAxj9hugCVAmy95Uois6NY-PIxsTY&usqp=CAU" alt="maydh">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSrmL0xwW2PkUGAzuIraklP4gfrIPPtdzuigw&s" alt="ceelsheekh">
        </div>
        <div class="text-content">
            <h2>Who We Are..</h2>
            <br>
            <h3>About</h3>
            <h1>We recommend beautiful destination</h1>
            <p>Explore the world’s most stunning destinations. From tropical beaches to historic 
                landmarks By default, list items are displayed vertically. In this example we use display: inline-block to display them horizontally</p>
            
            <a href="./about/about.php"><button class="btn">Read <img src="https://img.icons8.com/ios-filled/50/ffffff/arrow.png" alt=""/></button></a>
  </div>
    </div>
</section>
<br>
<br>
<br>
<br>

<section>
    <div class="package1">
            <h2>Some of the Packages</h2>

    </div>
    <div class="packages">
        <div class="package">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVTSXA68CsLV1E4cNZFlyE8iycYgNZnUnjjA&s" alt="Daallo">
            <h3>Daallo</h3>
            <div class="rating">&#11088; 4.5</div>
        </div>
        <div class="package">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSww_05KETpYVXI9ZWTpnXddMvf7HAHu6v_kA&s" alt="Sacaadadiin">
            <h3>Laas-Geel</h3>
            <div class="rating">&#11088; 3.5</div>
        </div>
        <div class="package">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOPHbCC2fD7T0I3DeG2xI95Xj6AfDvmQfDzA&s" alt="Ceel-Sheikh">
            <h3>Seylac</h3>
            <div class="rating">&#11088; 4.5</div>
        </div>
    </div>
</section>


<section class="tour">
    <div class="tour-h3">
  <h3>Tour Spotlight</h3>
</div>
  <div class="tour-spotlight">
    <img src="./1.jpg" alt="Beach Tour"> <!-- You can replace this with your own image path -->

    <div class="tour-card">
      <h2>Weekend Escape <br> Luxury by the Red Sea</h2>
      <p>Unwind in Berbera's finest resorts with a 3-day beachfront getaway<br>Unwind in Berbera's finest resorts with a 3-day beachfront getaway.</p>
     <a href="./toursites/toursites.php"><button>Learn More</button></a> 
    </div>
  </div>
</section>

<section class="destination-section">
    <h2>Find your best Destination</h2>
    <p>We have more than 200 destinations you can choose</p>
    <div class="destinations">
      <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhMTExMWFhUXGBcYGBcYGBgYFxoXFxgYFxcXGBoYHSggGBolHRcXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGi0lHyUtLS0tLS8tLS0tLSsuLS0tKy0tLS0tLS4tLS0rLSstLSstLS4tKy0tLSstKy0tLy0tK//AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAFAAIDBAYBB//EAEIQAAEDAgMECAQEBAUCBwAAAAEAAhEDIQQSMQVBUWEGEyJxgZGh8BQysdEVQlLBI5Lh8QcWU2KycuIzQ1RzgqLS/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QALBEAAgICAQMDAQgDAAAAAAAAAAECEQMSIQQTMUFRYfAiIzJSgZGhsRRx8f/aAAwDAQACEQMRAD8A9Dr1AhGKfdMxGPACFYnH81hjjRcpWTbTxUFoB1WJ2pWcSC688eSO1ajn9o7tFzC7LdViw7yF14pKPkwmmzIFyc150Wrf0WDXCXW1P2VHFbLDHETIBnmulZIvwYODXkO9GqwNBodbcB73LQYWkG6aLJ4HEhoa3T7cCjbdqtDdVy5INvg6ISVchWrjWtkkwAgu2dqgMlt5Q7FVyQZuCZjjwQ6pTBMmYB03IjiinbFLI34BFVjqjiRJOpH3RGphmtpCDB3kqc1uAhRudOq6NzHWgQA4QTopWYl25W8RRLosmNwTl0R5RizjKjz+Y9yJYXFFpHbgdyrUsMd6lOHIFzZOhGkwWNYfmcHfVXKeJZ+UBYem+D/cJ4xr2mdx4qHEpM9BY4cgpHRyWJpbZcRcHvUzNtnc1x81DgWpGixLOCpmiq+FxrnROnqiNKoDfN4WSoLICIULqis1hOhHmhtevuIPgigHPLVXe5qa1wJUWJw8944p0KxPqNTTTCoVWOGiZmqXF0UFncTiADAUIrSp27NLhJKK7J2a0uDbE6wTc9yfCAF0cK950gcUZwmyMt9/NEsHtHD5GvEEOrjDgTH8TPkI8NVonUQNyyc78GiiZduzzwT27OE3C0lo0CoYpzQpsqigKLeASTXVLpJC4KeOBLoCqYvDEEAXVnEV7y3uUFTHxzK5YnQWGUSWgEAIjgH5WyhNLHDVR4vGGxmytLbgV1yXdqbSy96AVKuaSDfWP6pVKhqmy4KBYCd/Ba4+HSIm7XJE+BcmOKZ1uawDo+qv0tnteJeYPAcFMGBrYA03fdbPJXgyULKLcSS3KQbcVG6tuU9V6hZQm6zfLKXCOZkg4cU8YQlObs2TYreMUZSk2RdYQp6VXeRKeNlHefVSNwJtBWt8GZXfWO5Ruru0goo3ZjuMd658EN7pTsVAMl3BMJfwWg+Fb7lL4Qf3SGZ3IeB+ilpu4yO4o4cIOI8k47Pn8zfJIYIYRuJJ7yFZbi6giGE9xRKnsadS334q5R2MRobckuAM87FVSdCO4/ZW8NSLmuBDi7WST5CFoGbPA+YqUYKNAUWBkhs+ruJHipqeDqaZitW2gOfouuosjVFgZxuznfqlWBsp0jei7qVMEdsSdAd8aq9QaI3KWNAF2z8okkNHEkAeZQ7pJ0eFWj1rXOzsBLHUyIPKZhX+k/RN2McCHhoAid41uPRYTGbMxmBqOFLrGsk5QHOGYNBBeQbEmTqP2XLly1akuDaMfVFDo0573somTlxPXFkhpzNYwkguIym3nC9r2ltajSpipVqMptO97gNd2tz3LwrZlYiqa7mTAOdpEh5JOXLwkWk2GVWKOIp4uvnrEuAsAQcjGxdg0AAmJnUzzXPHKoxtmjVs9Xdt+g7KWVWvBkZmkOAMT2o+WY370P8Axum9mcTEcDF/lHeReFj9q0mYNtZlEnqqlLPTk5i17L5TedQNeCG061YUhUa/fmAzZQHH5bAyXRfXQIfUPikLQN4nb1XMYflE6ZNPNJV6e38SBGdjuZYD9CPfHVJR3V+dh+her4pwNkn1SQJ1KOYPYbqjXECbCJ/ZQnZrAcsdoW8VojUzlSqWnWys08VJ7WnLipMZsp+e4idE2tgHCJBWiJZbZUj5R3q1haodObwVenhXcCrNCnyst4woxlMkzQuPYTor+CwoqHKBfW6tYjA5NR5f0Q9bp+QW1WvBnHYBx0UlHAvmEUr1xTsWf/YqsNoOEkABPVMW1cEbdmPJV3B7FqWIiTx4KCniKrwSIgLX7HaOqaSZMewss0+2rXk0xx3dMD19mhoMuv3WUFLBuF+yjmMoZwYWU2k+rSdYmOKMOZy4bDLjUeUi1Xw9XiFX+DfwVJm0qm8/RWGbWPFdPJz8DnUXjj5Jgov4fVTs2opxtXl6qrZPBU+Eqewqj8blJa50EGNP6I4zazf0+oWMxlF+Zxc4k6zzPcplJoqMUzTtw1U7ipG4SrxI8VV2BjmtpAGXOm08LaI9RrtIvb33pqVktFD4WrxPmnihWgmbD6IrSIO9Bul+Nq4emypSfLpINPKC1zbSS6JbA380Syaq2NRvwcZiDDiHBwa1rjEaOLgP+JQLF9LHZ+pbTJLmktcYykCzp3AiVk8D0ldSc/JmDKnzAAEBoLyABGnbJty4IftTadTI5heNALCDBJJM8Mo9RYaLzsvVzmkocG0cKXkube2jXdVo0xUs2i1pyn8rblxJPJuv7r0PoDjCcM4kPDmNksfmJ01BduJ8l5/0bZSq9a+pPWPAgwRLWwckaatB8lqsF0iqhpoNApSw5Q6+eA4loJHYMAeYvZc2LqlCTUrtfy6NZ4+FSH9JKVF8ddiHuqalrJiTENaAYAm1+BWZ2dSq5+toio2mIhtSoQ12smCIMgTHMIs3AlxzvGVlEiwEvqVXtBe55NwAX7tZEJ/WfEMe1jhTLIDz4SSy88ItaR4cc+qk/Cr3+vU2WP3GY3BGsDWAz5SDAa0OIMkxucQcvgbblW2f0JoupGq/EFnWAw065T8rngfK7luhENi7TuKTgHFwIL7QchaGmOJDjxmEG2vhPhsQ6jiCalCpJpOzlvVOcNHWMxu4xad0dPnlGbxyXyvlepplx3FT/QC7W6O4mi8trTUJJDXs7UtFjIFwNPEFQbL2a+q8UOr7QLs5IGVjey1rydCbFo10sJK0uF2FRZQb1gzXDi8ggSbBjQTP5iR52hFsBVp4ekxozSSXsz2c8jtMuSRlGYwJ46nXafW8Ptq34+CI4r5ZntobMwtKo6m512wDdwvAO4gJI9Wpkkl7HZjrGk+CSzjmlSt8/oaf4vyg9ndSeWNqODd37hXMMwEkm51VTBszG8nmVbYW/NOmvJerZzjqmQuBfu071FtDGAWAHoqm0doUcpE3HqgLnPfBAMGwnRWgoufFgWnejNHAuLQ5uVwN9boFs/YznPOY33cFs9l7KyNh7pPlb90+7ryT29uBbIoFkuIE7uSftHEnUhW3V2tEBCMbip0ElZOW8rZeuqpFPEYV9S4MeHOb+CYNlSATVI42+l7KT8TAADrE27u9Ca21HSQNCtlkklSM3ji3bCmGqilIzZhe+9Pp4wudZ0XB8EAFdxNhA4cVPhsDUcZnL9u5F3yw+EeiYHENcyBqgPSCkDM2n0U+xXto04c6SfRCek+JY5r4MuAjXiVzwi4z4NpO4gN1ANMO+yfUdTcwC0jQxr38VnquJMwSSBpdEdnPJiBO8zou1TbOVwSRZ6sab+EqWjTvp5KfD0Q8SZJOkad6mbs/qzqSDv8AutdnZlSo5SocoT/w/MSSbcEaoYMAa+a7iAGsc6WmOciYm8K20zNWgXgqNKS3OA4HKQZF92uqKfAxwXn219tyXWPeHWmdW6QOW7ijOw+lDYc57zLj2p0aA2BBFxuMnVYR6mF0aPE/JqamFBaQTE2nTXhzWQ6UFlBzaVLOakCMt3STA5XJ/oo9v9Muw3sguBEjR0GL2Ol9ChdfpGynVD4D3hpvwMFkAxoIN1ydR1cZ/Zir+TXFiaVtgTauFOZ2Zgpk2cR2jaZ32vyACjo9HXVeqzmGh+Wpuhou6JAIJ58d0I1Q2xUfUcxlJsVMusnK1kGdQDrqdTAXdpbcdTLZb/DZUDXQYeezpIJBsLbz2dF5855LSh5OyEIO234B218fQZVc1rRlpuc2m2MzQG9kCPlOhMmT5qTZXSJrKjc1CW3jKA25jLZttQd3BTO2hhn4jM9hZlBc4FsseXN7LjHy3Mm27cjuO2PRNfA4dmUh1R1RzmgSerbmAB3iN3isMk4Rio5Ivw/4Tv6+S4xldxaHbWfVY0VILWOu6wBLi67ah4gmxI0FpgKHo3s+o7A1qwIGepmZeOxIzSd0doGNMngg3+JeLFWs2izsig9zXOmQ5zg0tiN4AhaPo7VZTwzKOeWhx1DROZoJ7N4HzO8VlrPsRfq2nXwvpGkVF5mmBcY11LEsflsKuQEaCo9nZFxoAG6b48RnTDaPxdWmGM3hp75PZNr3MzzRzaWObRqGsRMucAwkFpykPpPAi+gHdUWf6KPr1qwNKlncDNRxADGmR2i42BtPmulQ1+9a/CuGyZNJOHuarC4Z1elQa5jnFrz12eZc+mZBP+0iDbu5i30ip525WtaSCySY0a6XNaRGh14jmnbNayizLUf1lU1C9z2zkv8AK0ZtwAnS55KPGRvyl05mtaIFhNtbyInee+Fy4pc8eOTojBRx/wCyKqys4l1JwDNw1iLETlO8HekrFGpDQJZ4vLT5C3lrqkth7lnZ8vcGtJMcEWq4LMwhziCQYJ3nhdCNmbRgt6tsZTcnhyWqqY6nAcYiNTr4BetN0ebFWZbB9E9H1nGImG7+Snx7WNd2W5R9UQx+3AB2W937WWSx+NJJM3KItvljlXoGG7TDFdG3cwHNYxld0yVdpVnOJyiwG4KmrJs0LsbM71R/EXtcQOE9yq4XO7l6K/SwoElxHn5QhIGwY3M9x5pxwZBElaTZuFpEw0SdJ596F9JGspODRrH1VcLgnllb8QFOzYHkfqu09u6LP1quYqNrCTAkpgaPG7VLmmChAZVqCCbKzhcA4DteCO7Lw2VmZ0BVFESlRTwnR2kYLnd8yip2PSOUNdAHqnurMGpUbsWPy3t/Za0kZXJhCjhGNgAiy7iG6Qo8JfXXeFaLQLnRV5RF0wXtPFuI6oUS7M2C4ugCwM9m+W4k2WZweLNAuHaLdQ6JYBvBF9wiecI30h2uI6tk3BBdY2tbj4clkqu0HtcKTzILbOynszYyLa203ELjzZGnwzaEOOUU+kG26dSpmpW3EAnK4g3cP08fBQtNPKKjKc3cIE3IjUzb6lc2tsgNpOe2o0OLsrWEQ5waASQZPEaxvRXZeGpnDikW3azNUOZom8gniZGXhrK8/Pk1ipHVihs6QJ29QL6AeWii8guc2SZgdktj5ZMjtC6r7OoU6ILa7HdZks0Fsi7SJBnnPALS19iOFR1dz5GdmWnFrloyugy4kSOUi24QbY2LTr13uq1HNq5IkGGh2gYDvacwAO8HdosIdRHXW+Pi/wBjbsN+PJU2XsVzgXAmCCxpc781nG+5rAI5krSVqFGtQq1CwPYHZWtmQXOIBIgcRFuaz209qvaygZIFN4pPgEZjAdVpnjotHtak4UoDmtzFnWRAbLs09wh7STwaVz5924turfH7nTjiqlFLwrZh6uyajf4tQAscIgHtsyk5XNnhlNpuCQrexekJo02Odd9DrWU5Mn+Iy2UakS2BP6iEQ2pVDw7DMJ/8LNSfPz1KMvBBGgyscI58bqbo/spk9fVptGIbBax0tGcsBzERrnkRumSutT7mP7xf8+uGc8YazWn8mf2jQqP2g+nkeczjVDBaXvALnE7gDOv6Y3wtVQ2YymQ11Nrg509sZzETEmwsDEDcn7X2mylVc7qi1xy/lJPZFhMnMN9ufBUP8xN7MUnPkSIDAR2SBMkmQLTyKcnKaVKlRprGEm2+S/0j2Y0AVQxmWmWuLNGljHCREQLnXuBnshFcBjKAw9Klh2OYHQYIy2Lt5JuSLk/2WY2nt+rWYWtoMAeJcS+8OnLm7MHQ2490pUK9eowjrWmXEB1MFxsW52wQAGgVGEnUAmFjkwbwSn6P3/stSW7aL+JrNY8sh8AEh0FzXNdPyuFiRpuibXQ7GbeqvnqKJexrpOcEHI0gQ2Igi/EQeS7jW5GBtd5dBLuzIguA7LbjgLwNTxVGltF7HOFMhjSWkA9twGVoFy28d30C3xwvnz/RlkmlwWmdLgPmpODpMjMOPekilLBYOq1tSoJe5oLicxkwBrIt4JI2j+UNW/UnyObYNdwlSU21YEHzRAPCcIXqHAmCq+GqASX+QVU0QdSZ7loOzwXCBusgewLwmFawh5B5SpHVzJDWwPJEQ3uPelk4QO4JUO0MoYV0Tcjf/ZD9p4dznbwNLC1vFEs1T9Y8k186CfNArRWwGDq/kqOZAgnS33UGO2I5zpNWe+STxVk9ZEA24TZVnCt7hMLIzsVrSDnRZuEY1lgNPd0Np1nA3k+S7jMY52lhwumLyTVqsNAnmTuHcqj8W6IBsOP2UbsW7LBA9VUFZAF6iDGYut70VvDbQLTDWyShbawPLnCTGQbElVZLRpcBXcCXHyniptrYrstAOpmEP2fSAZnLwIBgExJ4E7gsHtDbNX4hxaTTcRdoeX0wWmSWlw+U/vzUyypC09TaNe3P2nQXQBJv3j3uWe6QU4qkAg8xDgHG+uvmUK2jtV2IzEERyvAgXBgZddBI5odtDHdWBkJdJ1PDff6LkyyeR6pG0Y1yzm0XuAA9IvIjfv1KNdFdtNDywsL2kSbTGUSJA1GYkQNcyGsxbHZA5t3R3+J1aOavdHS2lUeIObLmhsucPlDZGguZjhM2WGRbY3Frk1xWpKSDWP2x12Y0wQ2m5whwLRJDml0jWMx4fRSYSg7q3vL2Pa7s0hOaQXB8k7iLGL6IHtvFxQeGkBxIAy6NiC65vcF3hGii2btRjYpU3EgscA4TGdoDjryDv5lzrp/sLRG/ce32gp0p6tuHphjQXGoC8GZD3Ne6ZOt7T3rmH2jUZSr9k1mdlphuZwa9g1jflBaDpcSq2HxFJ1EscAczsxEye00zE/mg6Dkh2A2tkaAwEt6qpIk9rKXZSY4uy6cRwWkcLcdauvce32978ov7JNOKME5KRqHMWukk5GmeyQRGcET+ZGBiXNqZusYZ3OJkEagkt/b+uLwGNeaWIqthsGmDvk1HQI4AAOVN3SGsTqxs2JyA+JmTztwXR2HJuvq+TPu0la+vBtNpVHYiXONBsSCC90yHOEkgaGZjfZDMLsBlOrSqvqshr2mBmIgEOufy380Bxu2KjajgMp0Blu8XOkb58CtJsrZ1bFYd1TrGMhpyt+XtOkNJcQez2XbwRI1SlGWNfipDiu421G2ufUbUwT+seWw9rqjXyHNAhtSs4svcnti0K30awjqFNzH1GMAqteHhoqZmEZXNi8ElrBMG8aqrQ2FXqFzqeKYQSZYM2ZhdfKYbqLW+6kx3R3FA1jTeDSewBhFaS1zCx0uE5mnsuMxvUyVrW0OPD2rkmLqmcj4kGYgMZkvIkEFpkQI1m/JU61AuFbPWGfNTA/3HK1rjAcMvzcI3cF3ZGx3hj3VHE1W5Or7RLYJcKsyL2ynXWVS+CxNbEVRQ+Vur7BjTlHzOO+W2AvZNJLi0S3J+jGYjBvLiesadN8bhwSV6jQqsGWo/tgmcrXEXJIgtEaEJJ7fKJ0fszTjFKRuLVQdHXH8o8wuu6Nu3AfzLs3Rz6suDFpfGKj/lt36mj/5JO6PH/Uv/ANQ//SNl7hqy+Mcu/Hc0N/BD/qHwdfyzLn4Of1v8xH/JO0KmFBjgu/HhC/wk/rf/ADf1XHbKduqO8UxUFTjgmfGjihzdkvM9t1oGnIGdOakp9H6rjar5gJOSXljUG/CLDsUFGcUOKkHRGrImuN/5RH5Y4X1Uo6HVP/UD+T/uWX+RiXqX2MnsUn4kcVC/EAovT6EnfiT4U/u5XKHQqj+arVd/K0f8SfVS+rxL1KXTZPYzHWBSNqhbKn0Vwg/8ue+o8n0MIhg9l0KfyUw3mHPB85WUuvj6Jmi6OXqzzfa+OZRbFYEZhLWuBGbmARcc1ladJ+JdGHoVKl75GuIm13EaeJ8l7hjdhYaq5r6lJtRzQAC8lxAGmWTa/BKhgWAAdQWtk2DzabSAHR9llLrE1evJrHpK4s8o2b/h7tC+ahl/MJe3mCDDo3g6H5RznQ0v8MH61jTOlg4iQJ4Mt5rfVsBSdlH8QARZr3DTcbrrMJRbYNJB4lzvrK5p9Vkl8G0engjC4foAGGc9GBFyXS2Ce0XTBtA4W46LA7MrUHE4dlCp1hEue4QQZZlyuBJEAGAN44LfmgyBDbeY8lVGy6eVoMnKANIJjfbQz+6jvTfk07cUuDzengKomadIw5w7FIkQHEEkuEXMXHHyX4TUdOUtZvsQzcdzfmPdYL0M7Cw+pY7fv1vNwNU8bNot+WkBOthfv09E3lbdjUIpUeb4nou90CnVZIhxeZblM3HdoJ5aJ3+VHXJxFNhc0gGDxYXRJE3GnAr00Yen+hhGglrSI4XSbSYD8rZ3GBInhA9wn35k9qBitl9BaDAQaxdJBIZTZkBywID84Nyd0gndAKVboPsxgc97KjovBc5sz/0gRf6FboVePvyAUT4Jkge/2Ud/L7srtwqqPPOj+z9mF1VuIwxe7OCx5NR2bN+QNbaGwLnXNyWxZhcLTpFjaVOhmbl7cZhaBFzMZoEc+9XKtFrvmay411ItuJCh+ApX/hUzP+1vrAupnKU/LZUEo3XqZLo7jMLh3V6eIgh1TOwwLzTYDY9rVu7iV0dJKGfK3DseJOY9VZu/8xC1jcJTBMU2Cd4EH092UZwNM6ta7dJaDIOtybobTduy4yjFUkZ+ntqm9sFrWNcAIYJy8btGXefIILsXE0aD62emKgc4FpdlcJAjLAkg+H1W7dgqUn+G0Hk0N3+N+aHV9h0XTIJn/e4AeAMJprlejDaHHugVV6QtkxRaB/7Lf3akrDui2FJk0h/Mfukjtw92V34/kQm+9FIBy9+ao/ElTCuves8Ciz5rhVV+K4KP4tFhReEcEjHsKtTrzvXHVUrHRabHAeSRI5JlMiOarVn+9UWBdZWA0Kd+IEKnhxKjxVjCiUFLyXGbj4CtPa4GolWqWLa6/aCzJepKZPGPfMLCfTRfg2j1D9TUh87ylm/3fRAqT3/6nhCbUxz2nWfAhc76aRss8Q78URxXPxA+5QBu1SdB9VINov4KOyyu4g4NoHgufHndKDDaTxuCd+KHijssO4gwdoO9hcGOJQoY0nefVSMqk7vVT26GphIY+N66NoHihrqxBgW8JTH4h2hd+yWg9gudpHfK78bzQUVOfquioeIRoh7Bn4z3KRxc+whTH8wk6oBvHclqFhI1/c/ZJ1fVC24kaA+dgl1593RqGwR60810VuP3QwYkrhxPEx3p6isKdeOK47FIZ8Rz+yYa++R78EahsEuu7kw1ULfik34pVoLYJFzkkJOLST1FZFgaZcQI1R5+B5DyH2QPZzyHAhGTiXQTm3cF6EmziiijjcEReEGrGCtH8UXDtEG3CPqhGMpDMYRFsGilh68FWG19U1uEBvdXGbO3wVVioiw9ZOqukqUYMD2VC6nfcjYTiWsA2/DmoNsyHWuI3qKjVIOgK5i6uYjcmBRdXPsKaniFw4cKWhRHuU7EWcPJFvunuZbgreDpiDY+EpmKFrTbiI/ulY6Br6PP1TOrKVVxnVRZ0McbJ2x7hPyHcR5BVOs5KVtVYs1RZyv/AFfROY54/N4qFtRSNqKHZaSLdIuOr/QJxo8z5BQsqeSnpvBWUi0IYXn+y78IP1FSSN33C44ndBUFDPheB810YQ/qkJ3WneuddzSoDnw2twnNw5B1H08F0V10OB3BIY3LG6eWnko2t4yPEFSOJniPNMzHl36Hv/ugCJ4AN2z4rhDdw/dS38fVMd3hMRWxDReB6f1VN1N277olUcTGvj+yiL43DxHsqkxA1wckrj3CdB6/ZdVWSPwwvKsZ8zSA4X4QVVab2Vim5dRzFWrSLfze/BQPrEmTCIuZKq4ikJgaq0A7CVWzdHsNTY8SAJ98Csw2mQiuHxAa3d77knGw2oJvwGsKjVwMGUQ2fiMwgEev7ldxdI8foo8OivKA3wBmVXfgzOqv4ipltmN+7yUOe2vmT91okyGysKV1LRbBT6NPMe7vV3CYQFDdCSss7Pw5I/sosfhyATJ4AHUfcInhcKQPmcNdI36ajchm1ze9iNDIk9+5Zp3I0apAJ7QoHsCmc2+pPvkmimtqsyTohyjmntYE40+SblUOBopjwxdazvTFKw7lk0ap2OG9dFQg7u/eurhYooomZWJ3p7Kp9VWAjeuhynUdlrPx9UwkC8qv10aHwTW1NfpwhToPYsConSeKiFSy62pO5LUdkvWeKf1qgFUckg7n78PHyS1YWWM8xfT6JHj77lBmCXWJahZI4aWn7phZxgev2Sa9OFROgIS32IhJSOcEkciOYOsMptJ93VVtXnHdBQw1yu9cYF/Dcu1I5S8/ESdffomvqwhznybJ6pCLoqKRj1TYSpWPhWmS0GNm18jp9+quYzH5t0eKACqV3rik0rsabCFarmVWFV+NPH35rhxPd9E7EEKboR7Y1UZLrKfE93vwRDAY97RofI/uomrRUeGaerig0EwTyQHG1A+C5sciZhcr7XMXyDvcPuEKq45xJObuAuPNRCNFSlZNUBlcDVSfjHe7fZM+IcTu99xWxnRfIPLyTcpVQVTxHqnMrHf6D+qAotZFGbHVR9fxjySLp3/RS1ZabRZpVGk9okeErvWDkRu3echU3MPv+yTZ5rNwLUwi+sHCHNGkA747xuG7vVZ7dIk8SYBPlb0UZcQmVKvu8KNaKs7iamUSd5iImJt38FEKh3CY4bvRc69u6PomFwMzPIA2mRczr6IoLJ/iDru4HT7pzcWSJsffNUswHslPbUa6ZaIHeNRBIIRQWW6mLytzOBA5gj/lA9Vz41oPzA8Li4P7qpSOQEBzsv6XZXAd0tkKu2kA4vGvjN9dDYeCVBYWGLBE+/HgnNxKD3kkOBE6GxA5EG/kkKgOjoPr66pajsNddwIB4gAHzTHPPFDRnER2xxblnxEj0CY7GHiQZ0Id62iPFGobBV1U/wBkkLGOO8X5SPRJGgtiS24+n9UiEklsjNiZR3+/qk90JJKkSxufnC66qISSTAcyqIn39U19eySSAIHYjuHmm/Ec0kkwI/iVJSxQHDy/dJJMkno4xsy5z+MDT1KbVxjTcA37kkkUFkTqomJPqntrD390kkDJWP8AfsJ/W+/ZKSSQHRV4D34BOD54juKSSARM3mT5lSsY3h6lJJIaHmi3gFG+iEkkhlGrQ7lAWpJJNDTOB3Eeq41dSUFIka6+q5fdu5+yUkkmMiqPEmSUzTd6pJJiGddxPkP6KN1dJJAmzhqDh9fukkknQWf/2Q==" alt="Mogadishu Beach">
      <img src="https://media.istockphoto.com/id/1299103449/photo/a-fishing-village-in-the-twilight.jpg?s=612x612&w=0&k=20&c=6e-9GZN6IZaCLEzCpQgRRKLOxl9Zh18DUrDFr1Rr0Pc=" alt="Sunset Beach">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWvFgyM6DeGage3dGVXiMg11KHYmQtNXugTQ&s" alt="Cave View">
    </div>
  </section>

  <section class="discover">
    
    <h1>Discover Top Picks for <br>Your Adventure</h1>
  
    <div class="search-container">
      <input type="text" placeholder="Search your next city">
      <button>Search</button>
    </div>
  </section>

  <section class="f">
    <footer>
      <div class="footer">
        <div class="footer-section">
          <div class="logo">
            <span style="color: #022e41;"> Dhul<span style="color:#0280b6;">mar</span>
          </div>
          <br>
          <p>Explore the world’s most stunning destinations. From tropical beaches to historic landmarks,
          Explore the world’s most stunning destinations. From tropical beaches to historic landmarks</p>
        </div>
  
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="./index.php">Home</a></li>
            <li><a href="./about/about.php">About</a></li>
            <li><a href="./packages/packages.php">Bookings</a></li>
            <li><a href="./hotels/hotels.php">Hotels</a></li>
            <li><a href="./toursites/toursites.php">Cities</a></li>
          </ul>
        </div>

        <div class="footer-section">
            <h3>Reach Us</h3>
            <ul>
              <li>Hargeisa Somaliland</li>
              <li>+252 5243667</li>
              <li>Down-Town</li>
              <li>Burj Omar</li>
              <li>Room 213</li>
            </ul>
          </div>
  
        <div class="footer-subscribe">
          <h3 style="color: #000;">Get In Touch</h3>
          <form>
            <textarea placeholder="Your email address..." required></textarea>
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>
  
      <div class="bottom-bar">
        <div>
          <img src="https://img.icons8.com/ios-filled/50/ffffff/copyright.png" alt="copyright">
          <span>copyright 2024</span>
        </div>
        <div>
          <img src="https://img.icons8.com/ios-filled/50/ffffff/phone.png" alt="Phone">
          <span>522633</span>
        </div>
      </div>
    </footer>
  </section>
</body>
</html>
