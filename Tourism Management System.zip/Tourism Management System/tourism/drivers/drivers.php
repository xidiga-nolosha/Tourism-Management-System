<?php
include '../dashboard/dbconn/dbconn.php';

// SQL Query to get the top three drivers, guiders, hotels, and packages

// Top three drivers
$query_drivers = "SELECT * FROM drivers ORDER BY expertyear DESC LIMIT 3";
$result_drivers = $conn->query($query_drivers);


// Display the results
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Our Drivers</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #fff;
      text-align: center;
    }

     /* Header/Navbar */
     header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

    .title {
      text-align: center;
      margin-top: 30px;
      color: #00cde2;
      font-size: 36px;
    }

    h2 {
      margin: 40px 0 30px;
      font-size: 24px;
    }

    .drivers-container {
      display: flex;
      justify-content: space-evenly;
      flex-wrap: nowrap;
      gap: 30px;
      padding: 0 20px 40px;
    }

    .driver-card {
      background-color: #a7e6eb;
      border-radius: 35px;
      padding: 30px 20px;
      width: 280px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .driver-card img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 20px;
    }

    .driver-name {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .driver-info {
      font-size: 14px;
      color: #333;
      margin-bottom: 20px;
    }

    .book-btn {
      background-color: #007fa6;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 30px;
      font-weight: bold;
      font-size: 16px;
      cursor: pointer;
    }

    .book-btn:hover {
      background-color: #005f7a;
    }
  </style>
</head>
<body>
    <!-- Header -->
    <header>
      <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
      <nav>
          <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>
              
          </ul>
      </nav>
      <a href="../login/login.php"><button class="login">Login</button></a>
  </header>
  <br>
  <br>
  <h2 style="color: #007fa6;">Our Professional Drivers</h2>
  <div class="drivers-container">
    <?php while ($driver = $result_drivers->fetch_assoc()): ?>
    <div class="driver-card">
      <img src="../dashboard/drivers/media/<?= htmlspecialchars($driver['imagepath']) ?>" alt="<?= htmlspecialchars($driver['fullname']) ?>" />
      <div class="driver-name"><?= htmlspecialchars($driver['fullname']) ?></div>
      <div class="driver-info">Experienced tour driver with <br /><b><?= $driver['expertyear'] ?></b> years of service.</div>
    </div>
    <?php endwhile; ?>
  </div>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>