<?php
include('../dashboard/dbconn/dbconn.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = $_POST['first']." ".$_POST['last'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $comment = trim($_POST['comment']);

    // Insert the comment into the database
    $sql = "INSERT INTO comments (fullname, email, phone, comment) VALUES ('$fullname', '$email', '$phone' , '$comment')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Comment submitted successfully!')</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f6ffff;
    }

        /* Header/Navbar */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

    .title {
      text-align: center;
      margin-top: 30px;
      color: #00cde2;
      font-size: 36px;
    }

        .contact-header {
      position: relative;
      background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e');
      background-size: cover;
      background-position: center;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 2.5rem;
      font-weight: bold;
      text-shadow: 2px 2px 6px #000;
    }

    /* 👇 Black overlay dusha image-ka */
    .contact-header::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4); /* 0.4 = 40% transparency */
      z-index: 0;
    }

    .contact-header {
      position: relative;
      z-index: 1; /* si text-ku dusha uga muuqdo overlay-ga */
    }


    .contact-form {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px 20px;
      background-color: #f6ffff;
    }

    input, textarea {
      width: 270px;
      max-width: 50%;
      padding: 15px;
      margin: 10px;
      border: none;
      border-radius: 50px;
      background-color: #c0e6e6;
      font-size: 1rem;
      outline: none;
    }

    textarea {
      border-radius: 30px;
      height: 150px;
      resize: none;
      width: 200%;
    }

    

    .form-row {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
    }

    button {
      padding: 15px 40px;
      border: none;
      border-radius: 50px;
      background-color: #00c4cc;
      color: white;
      font-size: 1.2rem;
      font-weight: bold;
      margin-top: 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    button:hover {
      background-color: #00a9b0;
    }
    
    
  </style>
</head>
<body>
    <header>
        <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>

                
            </ul>
        </nav>
        <a href="../login/login.php"><button class="login">Login</button></a>
    </header>

    <div class="contact-header">
        <span style="position: relative; z-index: 1;">Contact Us</span>
    </div>

    <form action="contact.php" method="POST">
    <div class="contact-form">
      <div class="form-row">
        <input type="text" placeholder="Enter your  First name" name="first" />
        <input type="text" placeholder="Enter your Last name" name="last"/>
      </div>

        <div class="form-row">
            <div class="mar">
            <input type="tel" placeholder="Enter your Phone" name="phone"/>
            <input type="email" placeholder="Enter your Email" name="email"/>
            </div>
      
        </div>
        <textarea placeholder="Type your message here..." name="comment"></textarea>
        <button type="submit" value="submit" name="submit">Submit</button>
      </div>
      </form>
</body>
</html>



