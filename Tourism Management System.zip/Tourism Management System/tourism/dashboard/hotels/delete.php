<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid'])) {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['hotelid'])) {
    $id = intval($_GET['hotelid']);

    // Optional: Fetch and delete associated image
    $stmt = $conn->prepare("SELECT imagepath FROM hotels WHERE hotelid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $hotel = $result->fetch_assoc();
    $stmt->close();

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM hotels WHERE hotelid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {

        if (!empty($hotel['imagepath']) && file_exists("./media/" . $hotel['imagepath'])) {
            unlink("./media/" . $hotel['imagepath']);
        }
        // Redirect to user list page after successful deletion
        header("Location: ../hotels.php");
        exit();
    } else {
        echo "<script>alert('Error: " . $stmt->error." ')</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Hotel ID is not specified.')</script>";
}
?>
