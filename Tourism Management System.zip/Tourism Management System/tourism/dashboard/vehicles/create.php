<?php
session_start();
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driverid = $_POST['driverid'];
    $type = $_POST['type'];
    $model = $_POST['model'];
    $capacity = $_POST['capacity'];
    $platenumber = $_POST['platenumber'];
    $status = $_POST['status'];

      // Handle file upload
    if (isset($_FILES['imagepath']) && $_FILES['imagepath']['error'] === UPLOAD_ERR_OK) {

      // Get the temporary name and original name of the uploaded file
      $tmpName = $_FILES['imagepath']['tmp_name'];
      $originalName = $_FILES['imagepath']['name'];

      // Get the file extension
      $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

      // Sanitize the model name to be safe for filenames
      $safeModel = preg_replace("/[^a-zA-Z0-9_-]/", "", $_POST['model']);

      // Create a unique file name
      $newFileName = $safeModel . "_" . time() . "." . $extension;

      // Define the target upload path
      $uploadPath = "./media/" . $newFileName;

      // Move the uploaded file to the destination folder
      if (move_uploaded_file($tmpName, $uploadPath)) {
          $imagepath = $newFileName; // You can store this in your database
      } else {
          echo "<script>alert('Failed to upload image.');</script>";
          exit();
      }
    } 
    else {
        echo "<script>alert('No image uploaded or upload error occurred.');</script>";
        exit();
    }
    $stmt = $conn->prepare("INSERT INTO vehicles (driverid, type, model, imagepath, capacity, platenumber, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssiss", $driverid, $type, $model, $imagepath, $capacity, $platenumber, $status);

    if ($stmt->execute()) {
        header("Location: ../vehicles.php");
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Add New Vehicle</title>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="../style.css">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .table-container {
      width: 100%;
      margin-top: 10px;
      background: #ffffff;
      border-radius: 6px;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead {
      background-color: #4f46e5;
      color: white;
    }

    th,
    td {
      padding: 1rem;
      text-align: left;
    }

    tbody tr:nth-child(even) {
      background-color: #f3f4f6;
    }

    tbody tr:hover {
      background-color: #f2f4fa;
    }

    th {
      font-weight: 600;
    }

    @media (max-width: 600px) {

      table,
      thead,
      tbody,
      th,
      td,
      tr {
        display: block;
      }

      thead {
        display: none;
      }

      tr {
        margin-bottom: 1rem;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      }

      td {
        display: flex;
        justify-content: space-between;
        padding: 0.75rem;
        border-bottom: 1px solid #e5e7eb;
      }

      td::before {
        content: attr(data-label);
        font-weight: bold;
        color: #4b5563;
      }
    }
  </style>
</head>

<body>
  <!-- SIDEBAR -->
  <section id="sidebar">
    <a href="../dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
    <ul class="side-menu">

      <li class="divider" data-text="main">Main</li>
      <?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="../users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="../toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="../guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="../vehicles.php"><i class='bx bxs-truck icon' ></i> Vehicles</a></li>
			<li><a href="../drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="../hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="../comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff'])): ?>
			<li><a href="../packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff', 'customer'])): ?>
			<li><a href="../payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<li><a href="../orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>


    </ul>
  </section>
  <!-- SIDEBAR -->

  <!-- NAVBAR -->
  <section id="content">
    <!-- NAVBAR -->
    <nav>
      <i class='bx bx-menu toggle-sidebar'></i>
      
      <a href="#" class="nav-link">
        <i class='bx bxs-bell icon'></i>
        <span class="badge">5</span>
      </a>
      <a href="#" class="nav-link">
        <i class='bx bxs-message-square-dots icon'></i>
        <span class="badge">8</span>
      </a>
      <span class="divider"></span>
      <div class="profile">
       <img src="./users/media/<?= $_SESSION['image']; ?>" width="60px" height="70px" alt="profile image">
        <ul class="profile-link">
          <li><a href="../profile/profile.php"><i class='bx bxs-user-circle icon'></i> Profile</a></li>
          <li><a href="../logout.php"><i class='bx bxs-log-out-circle'></i> Logout</a></li>
        </ul>
      </div>
    </nav>
    <!-- NAVBAR -->
    <!-- MAIN -->
    <main>
      <h1 class="us-title font-medium ">Add Vehicle</h1>
      <section class="table-container">
        <main>
          <div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
            <form action="create.php" method="POST" enctype="multipart/form-data">
              <div class="mb-4">
                <label class="block font-medium mb-1">Driver ID</label>
                <input type="number" name="driverid" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Type</label>
                <input type="text" name="type" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Model</label>
                <input type="text" name="model" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Image path</label>
                <input type="file" accept="image/*" name="imagepath" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Capacity</label>
                <input type="number" name="capacity" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Plate number</label>
                <input type="text" name="platenumber" required class="w-full border px-3 py-2 rounded">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Status</label>
                <select name="status" required class="w-full border px-3 py-2 rounded">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                Add Vehicle
              </button>
            </form>
          </div>
        </main>
      </section>


    </main>
    <!-- MAIN -->
  </section>
  <!-- NAVBAR -->

  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <script src="../script.js"></script>
</body>

</html>