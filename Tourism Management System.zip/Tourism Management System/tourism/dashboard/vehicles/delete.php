<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['vid'])) {
    $id = intval($_GET['vid']);

    // Optional: Fetch and delete associated image
    $stmt = $conn->prepare("SELECT imagepath FROM vehicles WHERE vid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $vehicle = $result->fetch_assoc();
    $stmt->close();

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM vehicles WHERE vid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {

        // Delete image if exists
        if (!empty($vehicle['imagepath']) && file_exists("./media/" . $vehicle['imagepath'])) {
            unlink("./media/" . $vehicle['imagepath']);
        }
        // Redirect to user list page after successful deletion
        header("Location: ../vehicles.php");
        exit();
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Vehicle ID is not specified.');</script>";
}
?>
