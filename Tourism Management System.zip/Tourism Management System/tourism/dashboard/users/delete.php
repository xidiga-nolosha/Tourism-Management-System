<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['userid'])) {
    $id = intval($_GET['userid']);

    // Optional: Fetch and delete associated image
    $stmt = $conn->prepare("SELECT imagepath FROM users WHERE userid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM users WHERE userid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {

         if (!empty($user['imagepath']) && file_exists("./media/" . $user['imagepath'])) {
            unlink("./media/" . $user['imagepath']);
        }

        // Redirect to user list page after successful deletion
        header("Location: ../users.php");
        exit();
    } 
    else {
       
        $errorMsg = htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8');
        echo "<script>alert('Database Error: $errorMsg'); window.history.back();</script>";

    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('User ID is not specified.');</script>";
}
?>
