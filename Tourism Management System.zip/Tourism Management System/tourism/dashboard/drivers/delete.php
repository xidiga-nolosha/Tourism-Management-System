<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || !$_SESSION[]['role'] == 'admin') {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['driverid'])) {
    $id = intval($_GET['driverid']);

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM drivers WHERE driverid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {
        // Redirect to user list page after successful deletion
        header("Location: ../drivers.php");
        exit();
    } else {
        echo "<script>alert('Error: " . $stmt->error." ')</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Driver ID is not specified.')</script>";
}
?>
