<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || !in_array($_SESSION['role'],['admin','staff'])) {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['pid'])) {
    $id = intval($_GET['pid']);

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM payments WHERE pid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {
        // Redirect to user list page after successful deletion
        header("Location: ../payments.php");
        exit();
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Payment ID is not specified.');</script>";
}
?>
