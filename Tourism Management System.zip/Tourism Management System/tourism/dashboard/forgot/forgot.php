<?php
session_start();
require_once '../dbconn/dbconn.php';

$stage = 1;
$securityquestion = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Step 1: Verify Email & Phone
    if (isset($_POST['step']) && $_POST['step'] == '1') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);

        if (!empty($email) && !empty($username)) {
            $stmt = $conn->prepare("SELECT secques FROM users WHERE email = ? AND username = ?");
            $stmt->bind_param("ss", $email, $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($securityquestion);
                $stmt->fetch();
                $_SESSION['resetemail'] = $email;
                $_SESSION['resetusername'] = $username;
                $_SESSION['securityquestion'] = $securityquestion;
                $stage = 2;
            } else {
                echo "<script>alert('Invalid email or username.')</script>"; // Use JavaScript to display the alert
            }
            $stmt->close();
        } else {
            echo "<script>alert('All fields are required.')</script>"; // Use JavaScript to display the alert 
        }
    }

    // Step 2: Check security answer + update password
    if (isset($_POST['step']) && $_POST['step'] == '2') {
        $email = $_SESSION['resetemail'] ?? '';
        $username = $_SESSION['resetusername'] ?? '';
        $securityanswer = trim($_POST['secans']);
        $newpassword = trim($_POST['password']);
        $confirmpassword = trim($_POST['confirm']);

        if (empty($securityanswer) || empty($newpassword) || empty($confirmpassword)) {
            echo "<script>alert('All fields are required.')</script>";
            $stage = 2;
        } elseif ($newpassword !== $confirmpassword) {
            echo "<script>alert('Passwords do not match.')</script>"; // Use JavaScript to display the alert
            $stage = 2;
        } else {
            $stmt = $conn->prepare("SELECT userid FROM users WHERE email = ? AND username = ? AND secans = ?");
            $stmt->bind_param("sss", $email, $username, $securityanswer);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $hashed = password_hash($newpassword, PASSWORD_BCRYPT);
                $update = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $update->bind_param("ss", $hashed, $email);
                if ($update->execute()) {
                    echo "<script>alert('Password reset successful. You can now login.')</script>"; // Use JavaScript to display the alert
                    session_destroy();
                    $stage = 1;
                } else {
                    echo "<script>alert('Failed to update password.')</script>"; // Use JavaScript to display the alert
                    $stage = 2;
                }
                $update->close();
            } else {
                echo "<script>alert('Incorrect security answer.')</script>"; // Use JavaScript to display the alert
                $stage = 2;
            }
            $stmt->close();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', sans-serif;
    }
    body {
      background: #f1f5f9;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .login-container {
      background: white;
      padding: 40px;
      border-radius: 22px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
    }
    .login-container h2 {
      margin-bottom: 25px;
      text-align: center;
      color: #049acc;
    }
    .form-group {
      margin-bottom: 20px;
      position: relative;
    }
    .form-group input {
      width: 100%;
      padding: 12px 40px 12px 16px;
      border: 1px solid #ccc;
      border-radius: 22px;
      padding-left: 40px;
    }
    .form-group .icon {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #049acc;
    }
    .login-btn {
      width: 100%;
      padding: 12px;
      background-color: #049acc;
      color: white;
      border: none;
      border-radius: 22px;
      cursor: pointer;
      font-size: 16px;
    }
    .login-btn:hover {
      background-color: #046e9f;
    }
    .forgot-password {
      text-align: right;
      margin-top: 10px;
    }
    .forgot-password a {
      color: #049acc;
      text-decoration: none;
      font-size: 14px;
    }
    .forgot-password a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Admin Login</h2>
    <?php if ($stage === 1): ?>
    <form action="forgot.php" method="POST">
      <input type="hidden" name="step" value="1">
      <div class="form-group">
        <input type="text" id="username" name="username" placeholder="|  Enter username" autocomplete="off">
        <i class="fas fa-lock icon"></i>
      </div>
      <div class="form-group">
        <input type="email" id="email" name="email" placeholder="|  Enter email" autocomplete="off">
        <i class="fas fa-envelope icon"></i>
      </div>
      <button type="submit" class="login-btn">Verify</button>
  </form>
  <?php elseif ($stage === 2): ?>
  <form action="forgot.php" method="POST">
      <input type="hidden" name="step" value="2">
      <div class="form-group">
        <input type="text" id="secques" name="secques" placeholder="|  security question" autocomplete="off" value="<?= htmlspecialchars($_SESSION['securityquestion']) ?>" readonly>
        <i class="fas fa-envelope icon"></i>
      </div>
      <div class="form-group">
        <input type="text" id="secans" name="secans" placeholder="|  Enter security answer" autocomplete="off">
        <i class="fas fa-lock icon"></i>
      </div>
      <div class="form-group">
        <input type="password" id="password" name="password" placeholder="|  Enter password" autocomplete="off">
        <i class="fas fa-lock icon"></i>
      </div>
      <div class="form-group">
        <input type="password" id="confirm" name="confirm" placeholder="|  confirm password" autocomplete="off">
        <i class="fas fa-lock icon"></i>
      </div>
      <button type="submit" class="login-btn">Reset</button>
    </form>
    <?php endif; ?>
    <div class="forgot-password">
        <a href="../login.php">Log in?</a>
    </div>
  </div>
</body>
</html>
