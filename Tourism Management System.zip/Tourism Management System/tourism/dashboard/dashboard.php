<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    header("Location: ../index.php");
    exit();
}

include './dbconn/dbconn.php';
$totalOrdersStmt = $conn->prepare("SELECT COUNT(*) AS total FROM orders;");
$totalOrdersStmt->execute();
$totalOrdersResult = $totalOrdersStmt->get_result();
$orders = $totalOrdersResult->fetch_assoc()['total'];
$totalOrdersStmt->close();

$totalPaymentsStmt = $conn->prepare("SELECT COUNT(*) AS total FROM payments;");
$totalPaymentsStmt->execute();
$totalPaymentsResult = $totalPaymentsStmt->get_result();
$payments = $totalPaymentsResult->fetch_assoc()['total'];
$totalPaymentsStmt->close();

$totalUsersStmt = $conn->prepare("SELECT COUNT(*) AS total FROM users;");
$totalUsersStmt->execute();
$totalUsersResult = $totalUsersStmt->get_result();
$users = $totalUsersResult->fetch_assoc()['total'];
$totalUsersStmt->close();

$totalSitesStmt = $conn->prepare("SELECT COUNT(*) AS total FROM toursites;");
$totalSitesStmt->execute();
$totalSitesResult = $totalSitesStmt->get_result();
$sites = $totalSitesResult->fetch_assoc()['total'];
$totalSitesStmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="./style.css">
	<title>AdminSite</title>
</head>
<body>
	
	<!-- SIDEBAR -->
	<section id="sidebar" class="whiting">
		<a href="./dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
		<ul class="side-menu">
			
			<li class="divider" data-text="main">Main</li>
			<?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="./users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="./toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="./guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="./vehicles.php"><i class='bx bxs-truck icon' ></i> Vehicles</a></li>
			<li><a href="./drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="./hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="./comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff'])): ?>
			<li><a href="./packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff', 'customer'])): ?>
			<li><a href="./payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<li><a href="./orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>
		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- NAVBAR -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu toggle-sidebar' ></i>
			<a href="#" class="nav-link">
				<i class='bx bxs-bell icon' ></i>
				<span class="badge">5</span>
			</a>
			<a href="#" class="nav-link">
				<i class='bx bxs-message-square-dots icon' ></i>
				<span class="badge">8</span>
			</a>
			<span class="divider"></span>
			<div class="profile">
				<img src="./users/media/<?= $_SESSION['image']; ?>" alt="profile image">
				<ul class="profile-link">
					<li><a href="./profile/profile.php"><i class='bx bxs-user-circle icon' ></i> Profile</a></li>
					<li><a href="./logout.php"><i class='bx bxs-log-out-circle' ></i> Logout</a></li>
				</ul>
			</div>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<h1 class="title">Dashboard</h1>
			<ul class="breadcrumbs">
				<li><a href="./dashboard.php">Home</a></li>
				<li class="divider">/</li>
				<li><a href="./dashboard.php" class="active">Dashboard</a></li>
			</ul>
			<?php if ($_SESSION['role'] === 'admin'): ?>
			<div class="info-data">
				<div class="card">
					<div class="head">
						<div>
							<h2><?= $users; ?></h2>
							<p>Users</p>
						</div>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="<?= $users/100; ?>%"></span>
					<span class="label"><?= $users/100; ?>%</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2><?= $payments; ?></h2>
							<p>Payments</p>
						</div>
						<i class='bx bx-trending-down icon down' ></i>
					</div>
					<span class="progress" data-value="<?= $payments/100; ?>%"></span>
					<span class="label"><?= $payments/100; ?>%</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2><?= $orders; ?></h2>
							<p>Orders</p>
						</div>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="<?= $orders/100; ?>%"></span>
					<span class="label"><?= $orders/100; ?>%</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2><?= $sites; ?></h2>
							<p>Toursites</p>
						</div>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="<?= $sites/100; ?>%"></span>
					<span class="label"><?= $sites/100; ?>%</span>
				</div>
			</div>
			<div class="data">
				<div class="content-data">
					<div class="head">
						<h3>Sales Report</h3>
						<div class="menu">
							<i class='bx bx-dots-horizontal-rounded icon'></i>
							<ul class="menu-link">
								<li><a href="#">Edit</a></li>
								<li><a href="#">Save</a></li>
								<li><a href="#">Remove</a></li>
							</ul>
						</div>
					</div>
					<div class="chart">
						<div id="chart"></div>
					</div>
				</div>
				<div class="content-data"></div>
			</div>
			<?php endif; ?>
		</main>
		<!-- MAIN -->
	</section>
	<!-- NAVBAR -->

	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	<script src="./script.js"></script>
</body>
</html>