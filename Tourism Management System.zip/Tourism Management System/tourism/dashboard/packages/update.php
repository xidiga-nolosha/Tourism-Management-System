<?php
session_start();
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || !in_array($_SESSION['role'],['admin','staff'])) {
    header("Location: ../../index.php");
    exit();
}
if (isset($_GET['packageid'])) {
    $orderid = intval($_GET['packageid']);

    $stmt = $conn->prepare("SELECT * FROM packages WHERE packageid = ?");
    $stmt->bind_param("i", $orderid);
    $stmt->execute();

    $result = $stmt->get_result();
    $package = $result->fetch_assoc();

    $stmt->close();
}
?>

<?php
include '../dbconn/dbconn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $packageid = $_POST['packageid'];
    $packagename = $_POST['packagename'];
    $descrip = $_POST['descrip'];
    $price = $_POST['price'];
    $durationdays = $_POST['durationdays'];
    $hotelid = $_POST['hotelid'];
    $guiderid = $_POST['guiderid'];
    $vid = $_POST['vid'];
    $siteid = $_POST['siteid'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE packages SET packagename=?, descrip=?, price=?, durationdays=?, hotelid=?, guiderid=?, vid=?, siteid=?, status=? WHERE packageid=?");
    $stmt->bind_param("ssiiiiiisi", $packagename, $descrip, $price, $durationdays, $hotelid, $guiderid, $vid, $siteid, $status, $packageid);

    if ($stmt->execute()) {
        header("Location: ../packages.php");
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Add New Driver</title>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="../style.css">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .table-container {
      width: 100%;
      margin-top: 10px;
      background: #ffffff;
      border-radius: 6px;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead {
      background-color: #4f46e5;
      color: white;
    }

    th,
    td {
      padding: 1rem;
      text-align: left;
    }

    tbody tr:nth-child(even) {
      background-color: #f3f4f6;
    }

    tbody tr:hover {
      background-color: #f2f4fa;
    }

    th {
      font-weight: 600;
    }

    @media (max-width: 600px) {

      table,
      thead,
      tbody,
      th,
      td,
      tr {
        display: block;
      }

      thead {
        display: none;
      }

      tr {
        margin-bottom: 1rem;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      }

      td {
        display: flex;
        justify-content: space-between;
        padding: 0.75rem;
        border-bottom: 1px solid #e5e7eb;
      }

      td::before {
        content: attr(data-label);
        font-weight: bold;
        color: #4b5563;
      }
    }
  </style>
</head>

<body>
  <!-- SIDEBAR -->
  <section id="sidebar">
    <a href="../dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
    <ul class="side-menu">

      <li class="divider" data-text="main">Main</li>
      <?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="../users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="../toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="../guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="../vehicles.php"><i class='bx bxs-truck icon' ></i> Vehicles</a></li>
			<li><a href="../drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="../hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="../comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff'])): ?>
			<li><a href="../packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff', 'customer'])): ?>
			<li><a href="../payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<li><a href="../orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>
    </ul>
  </section>
  <!-- SIDEBAR -->

  <!-- NAVBAR -->
  <section id="content">
    <!-- NAVBAR -->
    <nav>
      <i class='bx bx-menu toggle-sidebar'></i>
      
      <a href="#" class="nav-link">
        <i class='bx bxs-bell icon'></i>
        <span class="badge">5</span>
      </a>
      <a href="#" class="nav-link">
        <i class='bx bxs-message-square-dots icon'></i>
        <span class="badge">8</span>
      </a>
      <span class="divider"></span>
      <div class="profile">
        <img src="./users/media/<?= $_SESSION['image']; ?>" width="60px" height="70px" alt="profile image">
        <ul class="profile-link">
          <li><a href="../profile/profile.php"><i class='bx bxs-user-circle icon'></i> Profile</a></li>
          <li><a href="../logout.php"><i class='bx bxs-log-out-circle'></i> Logout</a></li>
        </ul>
      </div>
    </nav>
    <!-- NAVBAR -->
    <!-- MAIN -->
    <main>
      <h1 class="us-title font-medium ">Edit TourismPackages</h1>
      <section class="table-container">
        <main>
          <div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
            <form action="update.php" method="POST">
              <input type="hidden" name="packageid" value="<?= $package['packageid']; ?>">
              <div class="mb-4">
                <label class="block font-medium mb-1">Package name</label>
                <input type="text" name="packagename" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['packagename']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Description</label>
                <textarea name="descrip" required class="w-full border px-3 py-2 rounded">
                  <?= htmlspecialchars($package['descrip']); ?>
                </textarea>
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Price</label>
                <input type="number" name="price" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['price']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Duration days</label>
                <input type="number" name="durationdays" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['durationdays']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Hotel ID</label>
                <input type="number" name="hotelid" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['hotelid']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Guider ID</label>
                <input type="number" name="guiderid" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['guiderid']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Vehicle ID</label>
                <input type="number" name="vid" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['vid']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">Site ID</label>
                <input type="number" name="siteid" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($package['siteid']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">status</label>
                <select name="status" required class="w-full border px-3 py-2 rounded">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                Update Package
              </button>
            </form>
          </div>
        </main>
      </section>

    </main>
    <!-- MAIN -->
  </section>
  <!-- NAVBAR -->

  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <script src="../script.js"></script>
  <script src="../script.js"></script>
</body>

</html>