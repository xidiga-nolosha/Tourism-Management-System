<?php
include './dbconn/dbconn.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collecting login data
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Query to get user data
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifying password
        if (password_verify($password, $user['password'])) {
            $_SESSION['userid'] = $user['userid'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['image'] = $user['imagepath'];
            header("Location: ./dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('User not found!');</script>";
    }
    $stmt->close();
    $conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', sans-serif;
    }
    body {
      background: #f1f5f9;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .login-container {
      background: white;
      padding: 40px;
      border-radius: 22px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
    }
    .login-container h2 {
      margin-bottom: 25px;
      text-align: center;
      color: #049acc;
    }
    .form-group {
      margin-bottom: 20px;
      position: relative;
    }
    .form-group input {
      width: 100%;
      padding: 12px 40px 12px 16px;
      border: 1px solid #ccc;
      border-radius: 22px;
      padding-left: 40px;
    }
    .form-group .icon {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #049acc;
    }
    .login-btn {
      width: 100%;
      padding: 12px;
      background-color: #049acc;
      color: white;
      border: none;
      border-radius: 22px;
      cursor: pointer;
      font-size: 16px;
    }
    .login-btn:hover {
      background-color: #046e9f;
    }
    .forgot-password {
      text-align: right;
      margin-top: 10px;
    }
    .forgot-password a {
      color: #049acc;
      text-decoration: none;
      font-size: 14px;
    }
    .forgot-password a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Admin Login</h2>
    <form action="login.php" method="POST">
      <div class="form-group">
        <input type="text" id="username" name="username" placeholder="|  Enter username" autocomplete="off" required>
        <i class="fas fa-envelope icon"></i>
      </div>
      <div class="form-group">
        <input type="password" id="password" name="password" placeholder="|  Enter password" autocomplete="off" required>
        <i class="fas fa-lock icon"></i>
      </div>
      <button type="submit" class="login-btn">Login</button>
      <div class="forgot-password">
        <a href="./forgot/forgot.php">Forgot Password?</a>
      </div>
    </form>
  </div>
</body>
</html>

