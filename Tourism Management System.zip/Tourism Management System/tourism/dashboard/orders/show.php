<?php
session_start();
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid'])) {
    header("Location: ../../index.php");
    exit();
}
if (isset($_GET['orderid'])) {
    $id = intval($_GET['orderid']);

    $stmt = $conn->prepare("SELECT * FROM orders WHERE orderid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="../style.css">
	<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
	<title>AdminSite</title>
	<style>
		
	
		.table-container {
		  width: 100%;
		  margin-top: 10px;
		  background: #ffffff;
		  border-radius: 6px;
		  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
		  overflow: hidden;
		}
	
		table {
		  width: 100%;
		  border-collapse: collapse;
		}
	
		thead {
		  background-color: #4f46e5;
		  color: white;
		}
	
		th, td {
		  padding: 1rem;
		  text-align: left;
		}
	
		tbody tr:nth-child(even) {
		  background-color: #f3f4f6;
		}
	
		tbody tr:hover {
		  background-color: #f2f4fa;
		}
	
		th {
		  font-weight: 600;
		}
	
		@media (max-width: 600px) {
		  table, thead, tbody, th, td, tr {
			display: block;
		  }
	
		  thead {
			display: none;
		  }
	
		  tr {
			margin-bottom: 1rem;
			background: #fff;
			border-radius: 8px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.1);
		  }
	
		  td {
			display: flex;
			justify-content: space-between;
			padding: 0.75rem;
			border-bottom: 1px solid #e5e7eb;
		  }
	
		  td::before {
			content: attr(data-label);
			font-weight: bold;
			color: #4b5563;
		  }
		}
	</style>
	<script>
		function printTableOnly() {
			const table = document.querySelector('.table-container').innerHTML;
			const style = `
				<style>
					table { width: 100%; border-collapse: collapse; }
					th, td { padding: 1rem; text-align: left; border: 1px solid #ddd; }
					thead { background-color: #4f46e5; color: white; }
					tbody tr:nth-child(even) { background-color: #f3f4f6; }
				</style>
			`;

			const printWindow = window.open('', '', 'height=600,width=800');
			printWindow.document.write('<html><head><title>Print Table</title>');
			printWindow.document.write(style);
			printWindow.document.write('</head><body>');
			printWindow.document.write(table);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		}
	</script>
</head>
<body>
	
	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="./dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
		<ul class="side-menu">
			
			<li class="divider" data-text="main">Main</li>
			<?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="../users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="../toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="../guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="../vehicles.php"><i class='bx bxs-truck icon' ></i> Vehicles</a></li>
			<li><a href="../drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="../hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="../comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff'])): ?>
			<li><a href="../packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff', 'customer'])): ?>
			<li><a href="../payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<li><a href="../orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>
		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- NAVBAR -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu toggle-sidebar' ></i>
			<form action="#">
				<div class="form-group">
					<input type="text" placeholder="Search...">
					<i class='bx bx-search icon' ></i>
				</div>
			</form>
			<a href="#" class="nav-link">
				<i class='bx bxs-bell icon' ></i>
				<span class="badge">5</span>
			</a>
			<a href="#" class="nav-link">
				<i class='bx bxs-message-square-dots icon' ></i>
				<span class="badge">8</span>
			</a>
			<span class="divider"></span>
			<div class="profile">
				<img src="./users/media/<?= $_SESSION['image']; ?>" width="60px" height="70px" alt="profile image">
				<ul class="profile-link">
					<li><a href="./profile/profile.php"><i class='bx bxs-user-circle icon' ></i> Profile</a></li>
					<li><a href="./logout.php"><i class='bx bxs-log-out-circle' ></i> Logout</a></li>
				</ul>
			</div>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<h1 class="us-title font-medium ">Order's Profile</h1>
			<p class="text-gray-600 text-sm mb-5 text-semibold">
				This table is holdes order's table
			</p><br />
			
				<button type="submit" onClick="printTableOnly()" style="color:white;background-color:green;padding:5px;border:1px solid green;border-radius:5px;">
					Print
				</button>
				<?php if ($order): ?>
			<div class="table-container">
				<table>
				  <thead>
					<tr>
					  <th>Order ID</th>
					  <td data-label="Order ID"><?= htmlspecialchars($order['orderid']); ?></td>
					</tr>
					<tr>
					  <th>User ID</th>
					  <td data-label="User ID"><?= htmlspecialchars($order['userid']); ?></td>
					</tr>
					<tr>
					  <th>Package ID</th>
					  <td data-label="Package ID"><?= htmlspecialchars($order['packageid']); ?></td></tr>
					  <tr>
					  <th>Booking date</th>
					  <td data-label="Booking date"><?= htmlspecialchars($order['bookingdate']); ?></td>
					</tr>
					<tr>
					  <th>Number of adults</th>
					  <td data-label="Number of adults"><?= htmlspecialchars($order['adults']); ?></td></tr>
					  <tr>
					  <th>Number of children</th>
					  <td data-label="Number of children"><?= htmlspecialchars($order['children']); ?></td>
					</tr>
					<tr>
					<th>Price</th>
					<td data-label="Price"><?= htmlspecialchars($order['price']); ?></td>
					</tr>
					<tr>
					  <th>Discount</th>
					  <td data-label="Discount"><?= htmlspecialchars($order['discount']); ?></td>
					</tr>
					<tr>		
					  <th>Status</th>
					  <td data-label="Status"><?= htmlspecialchars($order['status']); ?></td>
					</tr>
					<tr>		
					  <th>Created Date</th>
					  <td data-label="Created Date"><?= htmlspecialchars($order['createddate']); ?></td>
					</tr>
				  </thead>
				
				</table>
			  </div>
				<?php else: ?>
        		<p>Order not found.</p>
    			<?php endif; ?>
				<br />
				<center><a href="./update.php?orderid=<?= $_GET['orderid']; ?>" style="background-color:yellow;padding:5px;border:1px solid green;border-radius:5px;width:50%">
					Edit
				</a>
				</center>
		</main>
		<!-- MAIN -->
	</section>
	<!-- NAVBAR -->

	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	<script src="../script.js"></script>
</body>
</html>