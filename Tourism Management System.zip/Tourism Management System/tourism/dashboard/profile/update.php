<?php
session_start();
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid'])) {
    header("Location: ../../index.php");
    exit();
}
if (isset($_GET['userid'])) {
    $id = intval($_GET['userid']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE userid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $stmt->close();
}
?>

<?php
include '../dbconn/dbconn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['userid'];
    $fullname = $_POST['fullname'];
    $image = $_POST['image'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $pass = $_POST['password'];
    $secques = $_POST['secques'];
    $secans = $_POST['secans'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET fullname=?, imagepath=?, email=?, phone=?, username=?, password=?, secques=?, secans=?, role=? WHERE userid=?");
    $stmt->bind_param("sssssssssi", $fullname, $image, $email, $phone, $username, $pass, $secques, $secans, $role, $id);

    if ($stmt->execute()) {
        header("Location: ./profile.php");
    } else {
        echo "<script>alert('Error: ".$stmt->error." ');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Add New Driver</title>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="../style.css">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .table-container {
      width: 100%;
      margin-top: 10px;
      background: #ffffff;
      border-radius: 6px;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead {
      background-color: #4f46e5;
      color: white;
    }

    th,
    td {
      padding: 1rem;
      text-align: left;
    }

    tbody tr:nth-child(even) {
      background-color: #f3f4f6;
    }

    tbody tr:hover {
      background-color: #f2f4fa;
    }

    th {
      font-weight: 600;
    }

    @media (max-width: 600px) {

      table,
      thead,
      tbody,
      th,
      td,
      tr {
        display: block;
      }

      thead {
        display: none;
      }

      tr {
        margin-bottom: 1rem;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      }

      td {
        display: flex;
        justify-content: space-between;
        padding: 0.75rem;
        border-bottom: 1px solid #e5e7eb;
      }

      td::before {
        content: attr(data-label);
        font-weight: bold;
        color: #4b5563;
      }
    }
  </style>
</head>

<body>
  <!-- SIDEBAR -->
  <section id="sidebar">
    <a href="../dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
    <ul class="side-menu">

      <li class="divider" data-text="main">Main</li>
      <?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="./users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="./toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="./guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="./vehicles.php"><i class='bx bxs- icon' ></i> Transportation</a></li>
			<li><a href="./drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="./hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="./comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if ($_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin'): ?>
			<li><a href="./packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<li><a href="./payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<?php endif; ?>
			<?php if ($_SESSION['role'] === 'customer' || $_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin'): ?>
			<li><a href="./orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>
    </ul>
  </section>
  <!-- SIDEBAR -->

  <!-- NAVBAR -->
  <section id="content">
    <!-- NAVBAR -->
    <nav>
      <i class='bx bx-menu toggle-sidebar'></i>
      
      <a href="#" class="nav-link">
        <i class='bx bxs-bell icon'></i>
        <span class="badge">5</span>
      </a>
      <a href="#" class="nav-link">
        <i class='bx bxs-message-square-dots icon'></i>
        <span class="badge">8</span>
      </a>
      <span class="divider"></span>
      <div class="profile">
        <img src="../users/media/<?= $_SESSION['image']; ?>" width="60px" height="70px" alt="profile image">
        <ul class="profile-link">
          <li><a href="../profile/profile.php"><i class='bx bxs-user-circle icon'></i> Profile</a></li>
          <li><a href="../logout.php"><i class='bx bxs-log-out-circle'></i> Logout</a></li>
        </ul>
      </div>
    </nav>
    <!-- NAVBAR -->
    <!-- MAIN -->
    <main>
      <h1 class="us-title font-medium ">Edit User</h1>
      <section class="table-container">
        <main>
          <div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
            <form action="update.php" method="POST">
              <input type="hidden" name="id" value="<?= $user['userid']; ?>">
              <div class="mb-4">
                <label class="block font-medium mb-1">Full name</label>
                <input type="text" name="fullname" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['fullname']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">image</label>
                <input type="file" accept="image/*" name="image" class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['imagepath']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">email</label>
                <input type="email" name="email" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['email']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">phone</label>
                <input type="text" name="phone" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['phone']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">username</label>
                <input type="text" name="username" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['username']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">password</label>
                <input type="password" name="password" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['password']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">security question</label>
                <input type="text" name="secques" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['secques']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">security answer</label>
                <input type="text" name="secans" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['secans']); ?>">
              </div>
              <div class="mb-4">
                <label class="block font-medium mb-1">role</label>
                <select name="role" required class="w-full border px-3 py-2 rounded" value="<?= htmlspecialchars($user['role']); ?>">
                  <option value="admin">Admin</option>
                  <option>Customer</option>
                  <option>Staff</option>
                </select>
              </div>
              <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                Update User
              </button>
            </form>
          </div>
        </main>
      </section>

    </main>
    <!-- MAIN -->
  </section>
  <!-- NAVBAR -->

  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <script src="../script.js"></script>
  <script src="../script.js"></script>
</body>

</html>