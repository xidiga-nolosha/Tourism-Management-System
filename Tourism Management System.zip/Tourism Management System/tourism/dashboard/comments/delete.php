<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid'])) {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['commentid'])) {
    $id = intval($_GET['commentid']);

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM comments WHERE commentid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {
        // Redirect to user list page after successful deletion
        header("Location: ../comments.php");
        exit();
    } else {
        echo "<script>alert('Error: ')</script>" . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Comment ID is not specified.');</script>";
}
?>
