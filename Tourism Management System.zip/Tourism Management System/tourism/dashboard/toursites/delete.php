<?php
session_start();
// dbconn.php - Database Connection
include '../dbconn/dbconn.php';
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}
// Check if user ID is provided
if (isset($_GET['siteid'])) {
    $id = intval($_GET['siteid']);

    // Optional: Fetch and delete associated image
    $stmt = $conn->prepare("SELECT imagepath FROM toursites WHERE siteid = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $site = $result->fetch_assoc();
    $stmt->close();

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM toursites WHERE siteid = ?");
    $stmt->bind_param("i", $id);

    // Execute the delete operation
    if ($stmt->execute()) {

        if (!empty($site['imagepath']) && file_exists("./media/" . $site['imagepath'])) {
            unlink("./media/" . $site['imagepath']);
        }

        // Redirect to user list page after successful deletion
        header("Location: ../toursites.php");
        exit();
    } else {
        $errorMsg = htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8');
        echo "<script>alert('Database Error: $errorMsg'); window.history.back();</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Toursite ID is not specified.');</script>";
}
?>
