<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['userid']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../index.php");
    exit();
}

include './dbconn/dbconn.php';
/*$result = $conn->query("SELECT packageid,packagename,price,siteid FROM packages");
$packages = $result->fetch_all(MYSQLI_ASSOC);
$conn->close();*/
$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? '';
$perPage = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

$allowed_filters = ['packageid', 'packagename', 'durationdays', 'status', 'siteid', 'hotelid', 'guiderid', 'vid'];
$where = '';

if (!empty($search) && in_array($filter, $allowed_filters)) {
    $search = $conn->real_escape_string($search);
    $filter = $conn->real_escape_string($filter);
    $where = "WHERE $filter LIKE '%$search%'";
}

$total_query = $conn->query("SELECT COUNT(*) as total FROM packages $where");
$total = $total_query->fetch_assoc()['total'];
$totalPages = ceil($total / $perPage);

$query = "SELECT packageid, packagename, price, siteid FROM packages $where LIMIT $offset, $perPage";
$result = $conn->query($query);
if ($result) {
	$packages = $result->fetch_all(MYSQLI_ASSOC);
}
else{
	$packages = [];
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="style.css">
	<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
	<title>AdminSite</title>
	<style>
		
	
		.table-container {
		  width: 100%;
		  margin-top: 10px;
		  background: #ffffff;
		  border-radius: 6px;
		  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
		  overflow: hidden;
		}
	
		table {
		  width: 100%;
		  border-collapse: collapse;
		}
	
		thead {
		  background-color: #4f46e5;
		  color: white;
		}
	
		th, td {
		  padding: 1rem;
		  text-align: left;
		}
	
		tbody tr:nth-child(even) {
		  background-color: #f3f4f6;
		}
	
		tbody tr:hover {
		  background-color: #f2f4fa;
		}
	
		th {
		  font-weight: 600;
		}
	
		@media (max-width: 600px) {
		  table, thead, tbody, th, td, tr {
			display: block;
		  }
	
		  thead {
			display: none;
		  }
	
		  tr {
			margin-bottom: 1rem;
			background: #fff;
			border-radius: 8px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.1);
		  }
	
		  td {
			display: flex;
			justify-content: space-between;
			padding: 0.75rem;
			border-bottom: 1px solid #e5e7eb;
		  }
	
		  td::before {
			content: attr(data-label);
			font-weight: bold;
			color: #4b5563;
		  }
		}
		@media print {
			.action-column {
				display: none;
			}
		}
	</style>
	<script>
		function printTableOnly() {
			const table = document.querySelector('.table-container').innerHTML;
			const style = `
				<style>
					table { width: 100%; border-collapse: collapse; }
					th, td { padding: 1rem; text-align: left; border: 1px solid #ddd; }
					thead { background-color: #4f46e5; color: white; }
					tbody tr:nth-child(even) { background-color: #f3f4f6; }
				</style>
			`;

			const printWindow = window.open('', '', 'height=600,width=800');
			printWindow.document.write('<html><head><title>Print Table</title>');
			printWindow.document.write(style);
			printWindow.document.write('</head><body>');
			printWindow.document.write(table);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		}
	</script>
</head>
<body>
	
	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="./dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> Dhulmar</a>
		<ul class="side-menu">
			
			<li class="divider" data-text="main">Main</li>
			<?php if ($_SESSION['role'] === 'admin'): ?>
			<li><a href="./users.php"><i class='bx bxs-user icon' ></i> Users</a></li>
			<li><a href="./toursites.php"><i class='bx bxs-widget icon' ></i> Tour Site</a></li>
			<li><a href="./guiders.php"><i class='bx bxs-chart icon' ></i> Guiders</a></li>
			<li><a href="./vehicles.php"><i class='bx bxs-truck icon' ></i> Vehicles</a></li>
			<li><a href="./drivers.php"><i class='bx bxs-car icon' ></i> Drivers</a></li>
			<li><a href="./hotels.php"><i class='bx bxs-home icon' ></i> Hotels</a></li>
			<li><a href="./comments.php"><i class='bx bxs-coin icon' ></i> Comments</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff'])): ?>
			<li><a href="./packages.php"><i class='bx bxs-package icon' ></i> Tourism Packages</a></li>
			<?php endif; ?>
			<?php if (in_array($_SESSION['role'], ['admin', 'staff', 'customer'])): ?>
			<li><a href="./payments.php"><i class='bx bxs-coin icon' ></i> Payments</a></li>
			<li><a href="./orders.php"><i class='bx bxs-package icon' ></i> Order package </a></li>
			<?php endif; ?>


		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- NAVBAR -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu toggle-sidebar' ></i>
			<form action="packages.php" method="GET" style="display:flex;justify-content:space-evenly;">
				<!--<br />
				<div class="form-group">-->
					<i class='bx bx-search icon' style="align-self:center;"></i>
					<input type="text" name="search" placeholder="Search...">
					<i class='bx bx-filter icon' style="align-self:center;"></i>
					<select name="filter">
						<option value="packageid">Package ID</option>						
						<option value="packagename">Package name</option>						
						<option value="durationdays">Duration days</option>						
						<option value="status">Status</option>
						<option value="siteid">Site ID</option>						
						<option value="hotelid">Hotel ID</option>
						<option value="guiderid">Guider ID</option>
						<option value="vid">Vehicle ID</option>
	                </select>
				<!--</div>-->
				<button type="submit" name="submit" style="color:white;background-color:blue;padding:5px;border:1px solid green;border-radius:5px;">
					Search
				</button>
				<br />
			</form>
			<a href="#" class="nav-link">
				<i class='bx bxs-bell icon' ></i>
				<span class="badge">5</span>
			</a>
			<a href="#" class="nav-link">
				<i class='bx bxs-message-square-dots icon' ></i>
				<span class="badge">8</span>
			</a>
			<span class="divider"></span>
			<div class="profile">
				<img src="./users/media/<?= $_SESSION['image']; ?>" width="60px" height="70px" alt="profile image">
				<ul class="profile-link">
					<li><a href="./profile/profile.php"><i class='bx bxs-user-circle icon' ></i> Profile</a></li>
					<li><a href="./logout.php"><i class='bx bxs-log-out-circle' ></i> Logout</a></li>
				</ul>
			</div>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<h1 class="us-title font-medium ">Tourism Package's Table</h1>
			<p class="text-gray-600 text-sm mb-5 text-semibold">
				This table is holdes tourism package's table
			</p><br />
            <div style="display:flex;justify-content:space-between;color:white;">
				<a href="./packages/create.php" style="background-color:green;padding:5px;border:1px solid green;border-radius:5px;">
					New Package
				</a>
				<button type="button" onClick="printTableOnly()" style="background-color:green;padding:5px;border:1px solid green;border-radius:5px;">
					Print
				</button>
			</div>
			<div class="table-container">
				<table>
				  <thead>
					<tr>
					  <th>Package ID</th>
					  <th>Package name</th>
					  <th>Price</th>
					  <th>Site ID</th>
					  <th class="action-column">Actions</th>
					</tr>
				  </thead>
				  <tbody>
					<?php foreach ($packages as $package): ?>
					<tr>
					  <td data-label="Package ID"><?= $package['packageid']; ?></td>
					  <td data-label="Package name"><?= htmlspecialchars($package['packagename']); ?></td>
					  <td data-label="Price"><?= htmlspecialchars($package['price']); ?></td>
					  <td data-label="Site ID"><?= htmlspecialchars($package['siteid']); ?></td>
					  <td class="action-column" data-label="Actions">
						<a href="./packages/show.php?packageid=<?= $package['packageid']; ?>" style="background-color:yellow;padding:5px;border:1px solid green;border-radius:5px;">
							View
					 	</a>	
						&nbsp;	
						<a href="./packages/delete.php?packageid=<?= $package['packageid']; ?>" onclick="return confirm('Are you sure you want to delete this package?')" style="color:white;background-color:red;padding:5px;border:1px solid green;border-radius:5px;">
							Delete
					 	</a>
					  </td>
					</tr>
					<?php endforeach; ?>
				  </tbody>
				</table>
				<div style="margin-top: 20px; text-align:center;">
					<?php if ($totalPages > 1): ?>
						<?php for ($i = 1; $i <= $totalPages; $i++): ?>
							<a href="?page=<?= $i; ?>&search=<?= urlencode($search); ?>&filter=<?= urlencode($filter); ?>" style="margin: 0 5px; padding: 5px 10px; background-color: <?= $i == $page ? '#4f46e5' : '#e5e7eb'; ?>; color: <?= $i == $page ? 'white' : '#1f2937'; ?>; border-radius: 4px; text-decoration: none;">
								<?= $i; ?>
							</a>
						<?php endfor; ?>
					<?php endif; ?>
				</div>

			  </div>
			
		</main>
		<!-- MAIN -->
	</section>
	<!-- NAVBAR -->

	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	<script src="./script.js"></script>
</body>
</html>

