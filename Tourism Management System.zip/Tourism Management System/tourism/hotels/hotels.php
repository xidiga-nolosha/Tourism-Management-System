<?php
include '../dashboard/dbconn/dbconn.php';

// SQL Query to get the top three drivers, guiders, hotels, and packages


// Top three hotels
$query_hotels = "SELECT * FROM hotels ORDER BY rating DESC LIMIT 3";
$result_hotels = $conn->query($query_hotels);


// Display the results
?>
  


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Popular Hotels</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: rgb(0, 60, 80);
            position: fixed;
            width: 95%;
            top: 0;
            left: 0;
            height: 3%;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logo span {
            color: #008596;
        }

        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            font-weight: bold;
            font-size: small;
        }

        .login {
            background: #0a86a9;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }


    .hotels-section {
      padding: 40px;
      text-align: center;
    }

    .section-title {
      color: #00bcd4;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 30px;
    }

    .hotels-container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 20px;
    }

    .hotel-card {
      width: 220px;
      border-radius: 10px;
      overflow: hidden;
      background: #fff;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      position: relative;
      text-align: left;
      padding: 10px;
    }

    .hotel-card img {
      width: 100%;
      height: 140px;
      object-fit: cover;
      border-radius: 8px;
    }

    .star {
      position: absolute;
      top: 12px;
      right: 12px;
      font-size: 20px;
      color: gold;
    }

    .hotel-card h3 {
      margin: 10px 0 5px;
    }

    .hotel-card p {
      margin: 3px 0;
      color: gray;
    }

    .price {
      font-weight: bold;
      color: red;
    }

    .night {
      color: black;
      font-weight: normal;
    }

    .details-btn {
      display: inline-block;
      margin-top: 8px;
      padding: 6px 12px;
      background-color: #00bcd4;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 14px;
      transition: background-color 0.3s ease;
    }

    .details-btn:hover {
      background-color: #009db0;
    }
  </style>
</head>
<body>

    <header>
        <div class="logo" >Dhul<span style="color:#00bcd4;">mar</span></div>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../hotels/hotels.php">Hotels</a></li>
                <li><a href="../packages/packages.php">Packages</a></li>
                <li><a href="../guiders/guiders.php">Guiders</a></li>
                <li><a href="../about/about.php">Who we are</a></li>
                <li><a href="../drivers/drivers.php">Drivers</a></li>
                <li><a href="../contact/contact.php">Contact</a></li>

                
            </ul>
        </nav>
        <a href="../login/login.php"><button class="login">Login</button></a>
    </header>

  <!-- POPULAR HOTELS SECTION -->
  <section class="hotels-section">
    <h2 class="section-title">Popular Hotels</h2>
    <div class="hotels-container">
      <?php while ($hotel = $result_hotels->fetch_assoc()): ?>
      <!-- Hotel 1 -->
      <div class="hotel-card">
        <img src="../dashboard/hotels/media/<?= htmlspecialchars($hotel['imagepath']) ?>" alt="<?= htmlspecialchars($hotel['hotelname']) ?>" />
        <span class="star">⭐</span>
        <h3><?= htmlspecialchars($hotel['hotelname']) ?> Hotel</h3>
        <p><?= htmlspecialchars($hotel['location']) ?> , Somaliland</p>
        <p><?= htmlspecialchars($hotel['rating']) ?>⭐</p>
        <p class="price" style="color: red;"> <span class="night"><a href="https://<?= htmlspecialchars($hotel['website']) ?>"><?= htmlspecialchars($hotel['website']) ?></a></span></p>
        
      </div>
      <?php endwhile; ?>
      <!-- Hotel 2 --><!--
      <div class="hotel-card">
        <img src="https://i.ytimg.com/vi/Q8RHV83u8YI/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAsGMqTx46W7w_-2REyFXjmAYOgMg" alt="Damal Hotel" />
        <span class="star">⭐</span>
        <h3>Damal Hotel</h3>
        <p>Hargeisa , Somaliland</p>
        <p>Mar 14</p>
        <p class="price" style="color: red;"> <span class="night">night</span></p>
        
      </div>-->

      <!-- 
      <div class="hotel-card">
        <img src="https://media-cdn.tripadvisor.com/media/photo-s/1a/21/99/77/flowers-lovely-garden.jpg" alt="Rays Hotel" />
        <span class="star">⭐</span>
        <h3>Rays Hotel</h3>
        <p>Borama , Somaliland</p>
        <p>Mar 11</p>
        <p class="price" style="color: red;"> <span class="night">night</span></p>
        
      </div>-->

    </div>
  </section>
<?php
// Close the connection
$conn->close();
?>
</body>
</html>
