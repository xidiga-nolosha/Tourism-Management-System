-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2026 at 12:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dhulmar`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentid` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentid`, `fullname`, `phone`, `email`, `comment`) VALUES
(1, 'cabdi', 47368365843, 'fhwfwj@gnjr.fh', 'hellow brother'),
(2, 'cumar', 47368365843, 'fhwfwj@gnjr.fh', 'hellow brother'),
(4, 'Cabdilaahi Muuse', 633214218, 'fuaadmuuse123@gmail.com', 'waaryaadhaheen sxbyaal si wacan ma u fahanteen'),
(5, 'cabdi yare', 3679585, 'fuaadmuuse123@gmail.com', 'good trip');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `driverid` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `licensenumber` varchar(20) NOT NULL,
  `expertyear` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`driverid`, `fullname`, `imagepath`, `phone`, `licensenumber`, `expertyear`, `status`) VALUES
(1, 'caasha', '', 365462546, '365462546', 15, 'active'),
(2, 'faarax', 'faarax.jpeg', 365462546, '242h424b', 5, 'available'),
(3, 'cukuse', 'cukuse.jpeg', 365462546, '242h424b', 5, 'available');

-- --------------------------------------------------------

--
-- Table structure for table `guiders`
--

CREATE TABLE `guiders` (
  `guiderid` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `special` varchar(50) NOT NULL,
  `expertyear` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guiders`
--

INSERT INTO `guiders` (`guiderid`, `fullname`, `imagepath`, `phone`, `email`, `special`, `expertyear`, `status`) VALUES
(1, 'sundus faarax', 'sundus.jpeg', 73465736756, 'hdfhg@gjdjf.fj', 'hills', 12, 'active'),
(2, 'nimco', 'nimco.jpeg', 73465736756, 'hdfhg@gjdjf.fj', 'hills', 2, 'availabe'),
(3, 'khaalid', 'khaalid.jpeg', 73465736756, 'hdfhg@gjdjf.fj', 'hills', 2, 'availabe');

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `hotelid` int(11) NOT NULL,
  `hotelname` varchar(100) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `location` varchar(1000) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL,
  `website` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`hotelid`, `hotelname`, `imagepath`, `location`, `phone`, `email`, `rating`, `website`, `status`) VALUES
(1, 'carro edeg', 'carroedeg.jpeg', 'hargeisa', 27467, 'bhjd@dfbfbg.com', 4, 'fhg.com', 'active'),
(2, 'damal', 'damal.jpeg', 'hargeisa', 27467, 'bhjd@dfbfbg.com', 4, 'fhg.com', 'active'),
(3, 'ambasador', 'ambasador.jpeg', 'hargeisa', 27467, 'bhjd@dfbfbg.com', 4, 'fhg.com', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `packageid` int(11) NOT NULL,
  `bookingdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `adults` int(11) NOT NULL,
  `children` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `status` varchar(20) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `userid`, `packageid`, `bookingdate`, `adults`, `children`, `price`, `discount`, `status`, `createddate`) VALUES
(1, 1, 1, '0000-00-00 00:00:00', 3, 2, 200, 5, 'pending', '0000-00-00 00:00:00'),
(2, 2, 2, '0000-00-00 00:00:00', 3, 2, 200, 5, 'completed', '0000-00-00 00:00:00'),
(3, 3, 3, '0000-00-00 00:00:00', 3, 2, 200, 5, 'completed', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `packageid` int(11) NOT NULL,
  `packagename` varchar(500) NOT NULL,
  `descrip` text NOT NULL,
  `price` int(11) NOT NULL,
  `durationdays` int(11) NOT NULL,
  `hotelid` int(11) NOT NULL,
  `guiderid` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `siteid` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`packageid`, `packagename`, `descrip`, `price`, `durationdays`, `hotelid`, `guiderid`, `vid`, `siteid`, `status`) VALUES
(1, 'duurxula', 'waxa loo dalxiisayaa buurta gacan libaax', 100, 3, 1, 1, 1, 1, 'active'),
(2, 'duurxula', 'waxa loo dalxiisayaa buurta gacan libaax', 100, 3, 2, 2, 2, 2, 'active'),
(3, 'duurxula', 'waxa loo dalxiisayaa buurta gacan libaax', 100, 3, 3, 3, 3, 3, 'active'),
(4, 'gabooba', '                  waa dalxiis lagu tagayo xeebta saylac\r\n                                ', 50, 4, 1, 2, 3, 3, 'inactive'),
(5, 'laasgel', 'hahfhiunefjbub\r\n                ', 12, 1, 1, 1, 1, 1, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `packageid` int(11) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `paymethod` varchar(20) NOT NULL,
  `paystatus` varchar(20) NOT NULL,
  `paydate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`pid`, `orderid`, `userid`, `packageid`, `amount`, `paymethod`, `paystatus`, `paydate`) VALUES
(1, 2, 2, 2, 200, 'zaad', 'paid', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `toursites`
--

CREATE TABLE `toursites` (
  `siteid` int(11) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `location` varchar(500) NOT NULL,
  `descrip` text NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `toursites`
--

INSERT INTO `toursites` (`siteid`, `sitename`, `imagepath`, `location`, `descrip`, `status`) VALUES
(1, 'gacan libaax', 'gacanlibaax.jpeg', 'm/jeex', 'meel aad u qurxoon', 'active'),
(2, 'berbera', 'berbera.jpeg', 'saahil', 'meel aad u qurxoon', 'active'),
(3, 'boorama', 'boorama.jpeg', 'awdal', 'meel aad u qurxoon', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `imagepath` varchar(500) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `secques` varchar(1000) NOT NULL,
  `secans` varchar(1000) NOT NULL,
  `role` varchar(30) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `imagepath`, `email`, `phone`, `username`, `password`, `secques`, `secans`, `role`, `createddate`) VALUES
(1, 'xaliimo axmed', 'xaliimo_1748010799.jpeg', 'sv@kgg.jg', 27346782364, 'xaliimo', '$2y$10$N8P2xIn0knob5Cy.5TUPrO01v5ol0Ijs0TvcaPiLFVceAr11bOLU.', 'what is your favourite food', 'caano', 'admin', '2025-05-23 14:33:19'),
(2, 'caasha', 'caasha.jpeg', 'svh@kgg.jg', 27346782364, 'caasha', '$2y$10$YfK2LhFr.Rv1idf.8wrT/u/ME72pxiQx4JgNAqSj.CBLpnMIvxeie', 'what is your favourite food', 'fadiirad', 'admin', '2025-05-22 19:10:10'),
(3, 'sugule', 'sugule.jpeg', 'svh@kgg.jg', 27346782364, 'sugule', '$2y$10$YfK2LhFr.Rv1idf.8wrT/u/ME72pxiQx4JgNAqSj.CBLpnMIvxeie', 'what is your favourite food', 'fadiirad', 'staff', '2025-05-22 19:10:10'),
(10, 'Cabdilaahi Fu\'aad', NULL, 'fuaadmuuse123@gmail.com', 633214218, 'hebel', '$2y$10$N0XrNOeF/nRkZlHa8I4cGOXYW2HMpCZklJ2a9Tdw0GFk145FS2YZK', 'what is your favourite food', 'aamina', 'customer', '2025-05-22 18:41:00'),
(11, 'saaqo', NULL, 'fuaadmuuse123@gmail.com', 633214218, 'saaqo', '$2y$10$ok5nYqjxHi7ECMp8q09e5O6f9Rwd4zVJNf7zxlKHzVhqwaV.JatwO', 'what is your favourite food', 'pasta', 'customer', '2025-05-22 18:44:01'),
(12, 'cabdi yare', NULL, 'cabdi90@gmail.com', 4303030, 'cabdi', '$2y$10$XN/gb4UFLupO9WT5rFmmDOOYcppXF9oPrttiOfwJhWRlr7G9zQiYy', 'what are you doing', 'enjoying', 'customer', '2025-05-22 19:21:53'),
(14, 'hasan jama', 'omer_1748021899.jpeg', 'fuaadmuuse123@gmail.com', 633214218, 'omer', '$2y$10$jbHU5RtQU4V8V6K1hbqCfOz6Tlq.gfmoHWhMzBmwzxE0uF/3uTxrO', 'what is your favourite food', 'aamina', 'customer', '2025-05-23 17:38:19'),
(15, 'omer farhan', NULL, 'fuaadmuuse123@gmail.com', 633214218, 'omer12', '$2y$10$Whc.Af20F13QticJZAmcS.TlGQlVsHHqrU5vVj/0BKCCZ3dsddp1C', 'who is your mom', 'synb', 'admin', '2025-05-23 17:51:23');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `vid` int(11) NOT NULL,
  `driverid` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `capacity` bigint(20) NOT NULL,
  `platenumber` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`vid`, `driverid`, `type`, `model`, `imagepath`, `capacity`, `platenumber`, `status`) VALUES
(1, 1, 'raaxo', 'verosa', 'verosa1.jpeg', 4, 'd5554', 'active'),
(2, 2, 'raaxo', 'harrier', 'harrier2.jpeg', 4, 'd5554', 'active'),
(3, 3, 'xamuul', 'dyna', 'dyna3.jpeg', 4, 'd5554', 'active'),
(4, 2, 'bus', 'turbo', 'Hff7b84a853b74218acbb821be7d06f96E.png', 30, 'r5051', 'inactive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`driverid`);

--
-- Indexes for table `guiders`
--
ALTER TABLE `guiders`
  ADD PRIMARY KEY (`guiderid`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`hotelid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `packageid` (`packageid`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`packageid`),
  ADD KEY `hotelid` (`hotelid`),
  ADD KEY `guiderid` (`guiderid`),
  ADD KEY `vid` (`vid`),
  ADD KEY `siteid` (`siteid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `packageid` (`packageid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indexes for table `toursites`
--
ALTER TABLE `toursites`
  ADD PRIMARY KEY (`siteid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`vid`),
  ADD KEY `driverid` (`driverid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `driverid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `guiders`
--
ALTER TABLE `guiders`
  MODIFY `guiderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `hotelid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `packageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `toursites`
--
ALTER TABLE `toursites`
  MODIFY `siteid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`packageid`) REFERENCES `packages` (`packageid`);

--
-- Constraints for table `packages`
--
ALTER TABLE `packages`
  ADD CONSTRAINT `packages_ibfk_1` FOREIGN KEY (`hotelid`) REFERENCES `hotels` (`hotelid`),
  ADD CONSTRAINT `packages_ibfk_2` FOREIGN KEY (`guiderid`) REFERENCES `guiders` (`guiderid`),
  ADD CONSTRAINT `packages_ibfk_3` FOREIGN KEY (`vid`) REFERENCES `vehicles` (`vid`),
  ADD CONSTRAINT `packages_ibfk_4` FOREIGN KEY (`siteid`) REFERENCES `toursites` (`siteid`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`packageid`) REFERENCES `packages` (`packageid`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`);

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driverid`) REFERENCES `drivers` (`driverid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
